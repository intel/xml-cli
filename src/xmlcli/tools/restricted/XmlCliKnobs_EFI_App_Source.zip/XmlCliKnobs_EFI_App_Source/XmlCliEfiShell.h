/**
Copyright (c)  2022 Intel Corporation. All rights reserved
This software and associated documentation (if any) is furnished
under a license and may only be used or copied in accordance
with the terms of the license. Except as permitted by such
license, no part of this software or documentation may be
reproduced, stored in a retrieval system, or transmitted in any
form or by any means without the express written consent of
Intel Corporation.

@file:
  XmlCli.h

@brief:
  Definitions for XML CLI interface/Wrapper
**/

#ifndef _XMLCLI_MODULE_H
#define _XMLCLI_MODULE_H

#include <Uefi.h>
#include <Library/UefiLib.h>
#include <Library/ShellCEntryLib.h>
#include <Library/ShellLib.h>
#include <Library/PrintLib.h>
#include <Library/IoLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/UefiRuntimeServicesTableLib.h> // gRT
#include <Library/UefiBootServicesTableLib.h>    // gBS
#include <Protocol/SimpleFileSystem.h>
#include <Library/MemoryAllocationLib.h>
#include <Library/FileHandleLib.h>
#include <Library/BaseCryptLib.h>

#include "SharedMailbox.h"
#include "XmlCliApi.h"


#define CMOS_DRAM_SHARED_MAILBOX_ADDR_REG       0xF0    // 2 bytes CMOS Space for the DRAM Share Mailbox address [31:16]
#define CMOS_DRAM_SHARED_MAILBOX_ADDR_REG_GNR   0x78    // 2 bytes CMOS Space for the DRAM Share Mailbox address [31:16]

#define BIOS_KNOB_START_TAG             0x626F6E6B3C        // "<knob"
#define BIOS_KNOB_START_TAG_MASK        0xFFFFFFFFFF
#define BIOS_KNOB_START_TAG_SIZE        0x5

#define BIOS_KNOB_END_TAG_1             0x3E2F              // "/>"
#define BIOS_KNOB_END_TAG_1_MASK        0xFFFF
#define BIOS_KNOB_END_TAG_1_SIZE        0x2

#define BIOS_KNOB_END_TAG_2             0x3E626F6E6B2F3C    // "</knob>"
#define BIOS_KNOB_END_TAG_2_MASK        0xFFFFFFFFFFFFFF
#define BIOS_KNOB_END_TAG_2_SIZE        0x7

#define BIOS_KNOB_NAME_TAG              0x223D656D616E      // 'name="'
#define BIOS_KNOB_NAME_TAG_MASK         0xFFFFFFFFFFFF
#define BIOS_KNOB_NAME_TAG_SIZE         0x6

#define BIOS_KNOB_VARDID_TAG_1          0x65726F7473726176  // 'varstore'
#define BIOS_KNOB_VARDID_TAG_1_SIZE     0x8
#define BIOS_KNOB_VARDID_TAG_2          0x223D7865646E49    // 'Index="'
#define BIOS_KNOB_VARDID_TAG_2_MASK     0xFFFFFFFFFFFFFF
#define BIOS_KNOB_VARDID_TAG_2_SIZE     0x7

#define BIOS_KNOB_SIZE_TAG              0x223D657A6973      // 'size="'
#define BIOS_KNOB_SIZE_TAG_MASK         0xFFFFFFFFFFFF
#define BIOS_KNOB_SIZE_TAG_SIZE         0x6

#define BIOS_KNOB_OFFSET_TAG            0x223D74657366666F  // 'offset="'
#define BIOS_KNOB_OFFSET_TAG_MASK       0xFFFFFFFFFFFFFFFF
#define BIOS_KNOB_OFFSET_TAG_SIZE       0x8

#define BIOS_KNOB_ATTR_END              0x22                // '"'

#pragma pack(1)

typedef struct _KNOB_INPUT_DATA {
  CHAR8   ReqKnobName[64];
  UINT64  ReqKnobValue;
  BOOLEAN KnobFoundInXml;
  UINT8   KnobVarId;
  UINT32  KnobOffset;
  UINT8   KnobSize;
  UINT64  DefKnobValue;
  UINT64  CurrKnobValue;
  BOOLEAN KnobProcByCli;
  BOOLEAN InvalidInputKnobVal;
} KNOB_INPUT_DATA;

typedef struct _XML_CLI_DATA {
  VOID    *XmlCliApi;
  UINT32  DramMbAddress;
  UINT32  GbtXmlAddress;
  UINT32  XmlSize;
  UINT32  CliReqBuff;
  UINT32  CliResBuff;
  UINT32  LegacyMbAddr;
  UINT32  SetupKnobAddr;
  UINT32  SetupKnobSize;
  UINT32  BiosKnobsDataAddr;
  UINT32  BiosKnobsDataSize;
  UINT16  CommandId;
  UINT16  ReqKnobEntries;
  UINT16  ReqKnobValidEntries;
  UINT16  ReqKnobEntriesProcessed;
  BOOLEAN CliGen2_Enable;
  BOOLEAN DxeLoop;
  BOOLEAN XmlLiteOp;
} XML_CLI_DATA;

#pragma pack()

#endif //_XMLCLI_MODULE_H
