/** @file
    This is a sample XmlCli MEBx Driver integration.
    This code is to distributed and scoped for Intel Internal Only

    Copyright (c) 2022, Intel Corporation. All rights reserved.<AS>
**/

#include <XmlCliMebxRestricted.h>
#include <Library/MemoryAllocationLib.h>


EFI_GUID                  gMebxValidationProtocolGuid = { 0x75F3E025, 0xAA38, 0x4F19, {0x82, 0xEF, 0x15, 0x34, 0x69, 0xC4, 0x3C, 0x32 } };
MEBX_VALIDATION_PROTOCOL  *gMebxValidationProtocol;

/**
  This function is used to log into MEBx.
  
  @retval  Other        An error occurred.
  @retval  EFI_SUCCESS  Function executed successfully without error.
**/
EFI_STATUS
EFIAPI
XmlCliMebxLogIn (
  VOID
){
  EFI_STATUS  Status;
  CHAR8       DefaultPass[]="admin";  // Default Mebx log-in password
  CHAR8       NewPass[]="Admin!98";   // New password to be set for Mebx Log-in

  // This API will log-in with the default password and set new password
  Status = gMebxValidationProtocol->MebxLogin(DefaultPass, 5, NewPass, 8);
  if (EFI_ERROR (Status)) {
    Print(L"[XmlCliKnobs-ERROR] Mebx Login Failed with status : %r\n", Status);
    return Status;
  } else {
    Print(L"[XmlCliKnobs] Mebx LogIn status: %r\n", Status);
  }
  return EFI_SUCCESS;
}

/**
  Attempts to find given char inside string. If found, returns index of this char inside string.
  Otherwise, returns index that equals Length or points to null-terminator, whatever comes first

  @param[in] Value   ASCII Value of the char to be found
  @param[in] String  Pointer to the investigated string
  @param[in] Length  Max string length

  @retval  Position  Index of the found character
**/
UINT32
FindChar (
  IN CHAR8  Value,
  IN CHAR8  *String,
  IN UINT32 Length
  )
{
  UINT32 Position;
  Position = 0;
  while (Position < Length && String[Position] != '\0' && String[Position] != Value) {
    Position++;
  }
  return Position;
}

/**
  This function will call MebxSetHostDomainName API to set or update the host domain name
  based on input from user. User need to check if AMT is enabled before setting host domain name.
  API will validate the user input host domain name then update the domain name in FQDN structure.
  AMTHI Command for configuring FQDN is sent through HECI Interface to AMT Client.
  Afterwards it uses Heci Flow Portocol to send and receive a response.
  
  @param[in] HostDomainName  Contains the Host domain name for Mebx preffered 
                             by user.
  @param[in] IsLoggedIn      This flag avoid login multiple times in same boot.

  @retval  Other        An error occurred.
  @retval  EFI_SUCCESS  Function executed successfully without error.
**/
EFI_STATUS
EFIAPI
SetDomainName (
  CHAR16* HostDomainName,
  BOOLEAN IsLoggedIn
  )
{
  EFI_STATUS  Status;
  FQDN_DATA   FqdnData;

  //Print(L"[XmlCliKnobs] MEBx Set or update host domain name \n");

  if (IsLoggedIn == 0) {
    Status = XmlCliMebxLogIn();
    if (EFI_ERROR (Status)) {
      return Status;
    }
  }

  ZeroMem (&FqdnData, sizeof (FqdnData));
  FqdnData.Fqdn.Length     = (UINT16)StrLen (HostDomainName);
  UnicodeStrToAsciiStrS (HostDomainName, (CHAR8 *) &FqdnData.Fqdn.Buffer, MAX_STRING_LENGTH_FQDN);
  FqdnData.HostNameLength  = FindChar ('.', (CHAR8 *) &FqdnData.Fqdn.Buffer, FqdnData.Fqdn.Length);

  // User can enter their desired domain name to be configured
  Status = gMebxValidationProtocol->MebxUpdateFqdn (&FqdnData);
  if (EFI_ERROR (Status)) {
    Print(L"[XmlCliKnobs-ERROR] Mebx SetHostDomainName failed with error status : %r\n", Status);
    return Status;
  } else {
    Print(L"[XmlCliKnobs] Mebx SetHostDomainName status : %r\n", Status);
  }

  //Print(L"[XmlCliKnobs] Mebx host domain name configured \n");
  return EFI_SUCCESS;
}

/**
  This function will login to Mebx setuppage then enable AMT settings and set
  host domain name and activate network.

  @retval  Other        An error occurred.
  @retval  EFI_SUCCESS  Function executed successfully without error.
**/
EFI_STATUS
EFIAPI
EnableAMT (
  VOID
  )
{
  EFI_STATUS  Status;
  CHAR16      *HostDomainName=L"mtn.intel.com";  // Default host domain name to be set
  BOOLEAN     IsLoggedIn=0;

  Print(L"[XmlCliKnobs] Configuring AMT settings \n");

  Status = XmlCliMebxLogIn();
  if (EFI_ERROR (Status)) {
    return Status;
  } else {
    IsLoggedIn = 1;
  }

  // Input this API with 2 to fully enable AMT settings
  Status = gMebxValidationProtocol->MebxConfigureAmtState (MEBX_ENABLE_AMT_SETTINGS);
  if (EFI_ERROR (Status)) {
    Print(L"[XmlCliKnobs-ERROR] Mebx Enable AMT failed with error status : %r\n", Status);
    return Status;
  } else {
    Print(L"[XmlCliKnobs] Mebx Enable AMT status : %r\n", Status);
  }

  // Set the domain name as mtn.intel.com
  Status = SetDomainName(HostDomainName, IsLoggedIn);
  if (EFI_ERROR (Status)) {
    Print(L"[XmlCliKnobs-ERROR] Mebx SetHostDomainName failed with error status : %r\n", Status);
    return Status;
  } else {
    Print(L"[XmlCliKnobs] Mebx SetHostDomainName status : %r\n", Status);
  }

  // This API is used to configure KVM Feature state.
  Status = gMebxValidationProtocol->MebxConfigureKvmState (MEBX_KVM_ENABLE);
  if (EFI_ERROR (Status)) {
    Print(L"[XmlCliKnobs-ERROR] Mebx enable KVM settings failed with status : %r\n", Status);
    return Status;
  } else {
    Print(L"[XmlCliKnobs] Mebx enable KVM settings : %r\n", Status);
  }

  // This API is used to configure SOL and Storage Redirection state.
  Status = gMebxValidationProtocol->MebxConfigureSolStorageRedirectionState(MEBX_SOL_ENABLE,MEBX_IDER_ENABLE);
  if (EFI_ERROR (Status)) {
    Print(L"[XmlCliKnobs-ERROR] Mebx enable SOL and IDER failed with status : %r\n", Status);
    return Status;
  } else {
    Print(L"[XmlCliKnobs] Mebx enable SOL and IDER : %r\n", Status);
  }

  // This API will activate the network.
  Status = gMebxValidationProtocol->MebxActivateNetwork ();
  if (Status == EFI_SUCCESS || Status == EFI_ABORTED) {
    Print(L"[XmlCliKnobs] Mebx Network Activated : Success \n");
  } else {
    Print(L"[XmlCliKnobs] Mebx Network Activate failed with status : %r\n", Status);
    return Status;
  }

  Print(L"[XmlCliKnobs] Mebx Enabling AMT settings configured successfully \n");

  return EFI_SUCCESS;
}

/**
  This function will call MebxEnableDisable API with input parameter disable AMT settings.
  MebxEnableDisable API is used to enable or disable AMT settings based on user input.
  Based on the amt state HECI library will send Set User Capabilities State Request to ME.

  @retval  Other        An error occurred.
  @retval  EFI_SUCCESS  Function executed successfully without error.
**/
EFI_STATUS
EFIAPI
DisableAMT (
  VOID
  )
{
  EFI_STATUS  Status;

  Print(L"[XmlCliKnobs] MEBx Disable AMT settings \n");

  Status = XmlCliMebxLogIn();
  if (EFI_ERROR (Status)) {
    return Status;
  }

  // Input this API with 0 to disable AMT settings
  Status = gMebxValidationProtocol->MebxConfigureAmtState (MEBX_DISABLE_AMT_SETTINGS);
  if (EFI_ERROR (Status)) {
    Print(L"[XmlCliKnobs-ERROR] Mebx Disable AMT failed with error status : %r\n", Status);
    return Status;
  } else {
    Print(L"[XmlCliKnobs] Mebx Disable AMT status : %r\n", Status);
  }

  Print(L"[XmlCliKnobs] Mebx AMT settings disabled successfully \n");
  return EFI_SUCCESS;
}

/**
  Performs Intel(R) AMT full and partial unprovisioning flows.
  Performs unprovisiong, re-initializes AMTHI, and if full unprovision, resets the
  MEBx password to AMT.

  @param[in] UnprovisionType  Specifies Unprovisioning Type:
                              0 - partial unprovision
                              1 - full unprovision

  @retval EFI_SUCCESS  Unprovisioning successful
  @retval EFI_TIMEOUT  Timeout has occured
  @retval Others       Other error has occured
**/
EFI_STATUS
EFIAPI
Unprovisioning (
  UINT8 UnprovisionType
  )
{
  EFI_STATUS  Status;

  Print(L"[XmlCliKnobs] MEBx AMT full unprovisioning settings \n");
  Print(L"[XmlCliKnobs] Full unprovisioning will set most manageability settings to factory defaults.\n");
  Status = XmlCliMebxLogIn();
  if (EFI_ERROR (Status)) {
    return Status;
  }

  // Input this API with 1 to configure full unprovisioning state
  Status = gMebxValidationProtocol->MebxConductUnprovisioning (UnprovisionType);
  if (EFI_ERROR (Status)) {
    Print(L"[XmlCliKnobs-ERROR] MEBx AMT full unprovisioning failed with error status : %r\n", Status);
    return Status;
  } else {
    Print(L"[XmlCliKnobs] Mebx AMT full unprovisioning status : %r\n", Status);
  }

  Print(L"[XmlCliKnobs] Mebx AMT full unprovisioning successfully configured\n");
  return EFI_SUCCESS;
}

/**
  Update current PKI FQDN DNS Suffix.

  @attention Function is not allowed in POST_PROVISION State

  @param[in] NewPkiDns  New Fqdn Pki Dns suffix

  @retval EFI_SUCCESS            Command succeeded
  @retval EFI_INVALID_PARAMETER  NULL parameter
  @retval EFI_UNSUPPORTED        Current ME mode doesn't support this function
  @retval EFI_DEVICE_ERROR       HECI Device error, command aborts abnormally
  @retval EFI_TIMEOUT            HECI does not return the buffer before timeout
  @retval EFI_BUFFER_TOO_SMALL   Message Buffer is too small for the Acknowledge
**/
EFI_STATUS
EFIAPI
PKISuffixUpdate (
  CHAR16* PkiDnsSuffix
  )
{
  EFI_STATUS  Status;
  FQDN_SUFFIX_ANSI_STRING Fqdn;

  Print(L"[XmlCliKnobs] MEBx Set PKI FQDN DNS Suffix\n");

  if (PkiDnsSuffix == NULL) {
    return EFI_INVALID_PARAMETER;
  }

  Status = XmlCliMebxLogIn();
  if (EFI_ERROR (Status)) {
    return Status;
  }

  ZeroMem (&Fqdn, sizeof (Fqdn));
  Fqdn.Length  = (UINT16)StrLen (PkiDnsSuffix);
  UnicodeStrToAsciiStrS (PkiDnsSuffix, (CHAR8 *) &Fqdn.Buffer, MAX_STRING_LENGTH_FQDN_SUFFIX);

  // User can enter their desired Set PKI FQDN DNS Suffix to be configured
  Status = gMebxValidationProtocol->MebxUpdatePkiFqdnSuffix (&Fqdn);
  if (EFI_ERROR (Status)) {
    Print(L"[XmlCliKnobs-ERROR] Mebx Set PKI FQDN DNS Suffix failed with error status : %r\n", Status);
    return Status;
  } else {
    Print(L"[XmlCliKnobs] Mebx Set PKI FQDN DNS Suffix status : %r\n", Status);
  }

  Print(L"[XmlCliKnobs] Mebx Set PKI FQDN DNS Suffix configured \n");
  return EFI_SUCCESS;
}

CHAR8* GetKnobsString(CHAR16 *KnobArg)
{
  UINTN  ReadSize;
  CHAR8  *KnobsString=NULL;

  ReadSize = StrLen (KnobArg);
  KnobsString = AllocateZeroPool(ReadSize+4);  // 4 bytes with NULL value as a safety buffer
  if (KnobsString == NULL) {
    Print(L"Error Allocating ZeroPool, Alloc Size = 0x%X\n", ReadSize);
    return NULL;
  }
  UnicodeStrToAsciiStrS(KnobArg, KnobsString, (ReadSize+2));
  return KnobsString;
}

/**
  This function will configure AMT settings based on the user input.

  @retval  Other        An error occurred.
  @retval  EFI_SUCCESS  Function executed successfully without error.
**/
EFI_STATUS
EFIAPI
ConfXmlCliMebxInit (
  IN CHAR16 **Argv
  )
{
  EFI_STATUS  Status;
  CHAR8       *KnobsString=NULL;

  Status = gBS->LocateProtocol (&gMebxValidationProtocolGuid, NULL, (VOID**) &gMebxValidationProtocol);
  if (EFI_ERROR (Status)) {
    Print(L"[XmlCliKnobs-ERROR] Platform must implement this protocol to set/get Mebx settings\n");
    return Status;
  }

  if((((CHAR16*)Argv[2])[0] == L'A') && (((CHAR16*)Argv[2])[1] == L'P')) {
    KnobsString = GetKnobsString(Argv[3]);
    if (KnobsString == NULL) {
      return(0);
    }
    if(AsciiStrCmp(KnobsString, "EnableAMT") == 0) { // Operation == Enable AMT state??
      Status = EnableAMT ();
      return Status;
    }
    if(AsciiStrCmp(KnobsString, "SetHostDomainName") == 0) { // Operation == Set Host Domain Name??
      Status = SetDomainName ((CHAR16*)Argv[4], 0);
      return Status;
    }
    if(AsciiStrCmp(KnobsString, "SetUnprovisioning") == 0) { // Operation == Set Unprovisioning state??
      Status = Unprovisioning (MEBX_FULL_UNPROVISION);
      return Status;
    }
    if(AsciiStrCmp(KnobsString, "DisableAMT") == 0) {  // Operation == Disable AMT state??
      Status = DisableAMT ();
      return Status;
    }
    if(AsciiStrCmp(KnobsString, "PKISuffixUpdate") == 0) {  // Operation == PKI DNS suffix udpate??
      Status = PKISuffixUpdate ((CHAR16*)Argv[4]);
      return Status;
    } else {
      return EFI_INVALID_PARAMETER;
    }
  } else {
    return EFI_INVALID_PARAMETER;
  }
}