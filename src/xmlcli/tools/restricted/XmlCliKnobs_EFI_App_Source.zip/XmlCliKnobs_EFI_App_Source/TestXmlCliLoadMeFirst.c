/** @file
    A simple, basic, EDK II native, "hello" application to verify that
    we can build applications without LibC.

    Copyright (c) 2022, Intel Corporation. All rights reserved.<AS>
    This program and the accompanying materials
    are licensed and made available under the terms and conditions of the BSD License
    which accompanies this distribution. The full text of the license may be found at
    http://opensource.org/licenses/bsd-license.

    THE PROGRAM IS DISTRIBUTED UNDER THE BSD LICENSE ON AN "AS IS" BASIS,
    WITHOUT WARRANTIES OR REPRESENTATIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED.
**/

#include <Uefi.h>
#include <Library/UefiLib.h>
#include <Library/ShellCEntryLib.h>
#include <Library/ShellLib.h>
#include <Library/PrintLib.h>
#include <Library/IoLib.h>
#include <Library/BaseMemoryLib.h>
#include <Library/UefiRuntimeServicesTableLib.h> // gRT
#include <Library/UefiBootServicesTableLib.h>    // gBS
#include <Protocol/SimpleFileSystem.h>
#include <Library/MemoryAllocationLib.h>
#include <Library/FileHandleLib.h>
#include <Library/UefiDecompressLib.h>
#include "SharedMailbox.h"
#include "XmlCliApi.h"

#define CMOS_DRAM_SHARED_MAILBOX_ADDR_REG   0xF0    // 2 bytes CMOS Space for the DRAM Share Mailbox address [31:16]
RETURN_STATUS
UefiTianoDecompress (
  IN CONST VOID  *Source,
  IN OUT VOID    *Destination,
  IN OUT VOID    *Scratch,
  IN UINT32      Version
  );

#pragma pack(1)

typedef struct _XML_CLI_TEMP_DATA {
  UINT32  DramMbAddress;
  UINT32  LegacyMbAddr;
  UINT32  GbtXmlAddress;
  UINT32  XmlSize;
  UINT32  BiosKnobsDataAddr;
  UINT32  BiosKnobsDataSize;
} XML_CLI_TEMP_DATA;

#pragma pack()

XML_CLI_TEMP_DATA mXmlCliTempData;

UINT32  GetDramSharedMbAddr(VOID)
{
  UINT32  DramMbAddress=0;
  IoWrite8(0x72, (UINT8)CMOS_DRAM_SHARED_MAILBOX_ADDR_REG);
  DramMbAddress = (((UINT32)IoRead8(0x73)) << 16);
  IoWrite8(0x72, (UINT8)CMOS_DRAM_SHARED_MAILBOX_ADDR_REG+1);
  DramMbAddress = ( DramMbAddress | (((UINT32)IoRead8(0x73)) << 24) );
  return DramMbAddress;
}

BOOLEAN XmlValid(UINT32 GbtXmlAddress)
{
  UINT32  XmlSize;
  CopyMem((VOID*)&XmlSize, (VOID*)(UINTN)GbtXmlAddress, 4);

  if (XmlSize != 0 ) {
    if ( ( CompareMem((VOID*)(UINTN)(GbtXmlAddress + 0x04), "<SYSTEM>", 8) == 0 ) &&
         ( CompareMem((VOID*)(UINTN)(GbtXmlAddress + XmlSize - 7 ), "</SYSTEM>", 9) == 0 ) ) {
      return TRUE;
    }
  }
  return FALSE;
}

EFI_STATUS ParseDramSharedMb(XML_CLI_TEMP_DATA *XmlCliTempData)
{
  SHARED_MEMORY_TABLE   *SharedMbTbl;

  XmlCliTempData->DramMbAddress = GetDramSharedMbAddr();
  SharedMbTbl = (SHARED_MEMORY_TABLE*)(UINTN)XmlCliTempData->DramMbAddress;
  //Print(L"\nInside Parse Dram shared MB DramMdAddress :0x%x\n",XmlCliTempData->DramMbAddress );
  if( (SharedMbTbl->Header.BiosSignature == SHARED_MB_BIOS_SIG) && (SharedMbTbl->Header.BiosSignature2 == SHARED_MB_BIOS_SIG) ) {
    //Print(L"Dram Shared MailBox is Valid,  SharedMbAddress: 0x%X\n", SharedMbTbl);
    if(SharedMbTbl->Entry[0].Signature == LEG_MAILBOX_SIG) {
      if( SharedMbTbl->Entry[0].Offset > 0xFFFF) {
        XmlCliTempData->LegacyMbAddr = (UINT32)SharedMbTbl->Entry[0].Offset;
      } else {
        XmlCliTempData->LegacyMbAddr = (UINT32)(UINTN)((UINT8*)SharedMbTbl + SharedMbTbl->Entry[0].Offset);
      }
      if( (SharedMbTbl->Header.CliSpecVersion.ReleaseVersion > 0) || (SharedMbTbl->Header.CliSpecVersion.MajorVersion > 6) ) {
        CopyMem((VOID*)&XmlCliTempData->GbtXmlAddress, (VOID*)(UINTN)(XmlCliTempData->LegacyMbAddr + OFF_GEN2_GBT_ADDRESS), 4);  // Get the GBT Xml address from Cli Gen2 Offset since Cli Gen2 is enabled
      } else {
        CopyMem((VOID*)&XmlCliTempData->GbtXmlAddress, (VOID*)(UINTN)(XmlCliTempData->LegacyMbAddr + OFF_GBT_ADDRESS), 4);
      }
      if(XmlValid(XmlCliTempData->GbtXmlAddress)) {
        CopyMem((VOID*)&XmlCliTempData->XmlSize, (VOID*)(UINTN)XmlCliTempData->GbtXmlAddress, 4);
        //Print(L"PlatformConfig.xml is Valid,  XMLAddress: 0x%X  XmlSize = 0x%X\n", XmlCliTempData->GbtXmlAddress, XmlCliTempData->XmlSize);
      } else {
        Print(L"PlatformConfig.xml is not Valid,  XMLAddress: 0x%X  XmlSize = 0x%X\n", XmlCliTempData->GbtXmlAddress, XmlCliTempData->XmlSize);
        return EFI_NOT_FOUND;
      }
    }
  } else {
    Print(L"Dram Shared MailBox not Valid!, Address: 0x%X , aborting..\n", SharedMbTbl);
    return EFI_NOT_FOUND;
  }
  return EFI_SUCCESS;
}

UINT64 AndMask[] = {0, 0xFF, 0xFFFF, 0xFFFFFF, 0xFFFFFFFF, 0xFFFFFFFFFF, 0xFFFFFFFFFFFF, 0xFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFFFF};

/**
  Extracts Byte Size from given BIT size 
  @param[in] Bit Offset within the given Byte (max Value of 7)
  @param[in] Bit Size (max value of 63)

  @retval  UINT8 extracted byte Size
**/
UINT8
BitGetByteSize (
  IN UINT8  BitOffset,
  IN UINT8  BitSize
  )
{
  UINT8 ByteSize;
  ByteSize = BitOffset + BitSize;
  if(ByteSize % 8) {
    ByteSize = (ByteSize/8) + 1;
  } else {
    ByteSize = (ByteSize/8);
  }
  return ByteSize;
}

/**
  Extracts BIT Value from given Bit Offset for given Bit Size 

  @param[in] UINT64 input Value
  @param[in] Bit Offset within the given Byte (max Value of 7)
  @param[in] Bit Size (max value of 63)

  @retval  UINT64 extracted Value
**/
UINT64
BitExtractValue64 (
  IN UINT64 InputVal,
  IN UINT8  BitOffset,
  IN UINT8  BitSize
  )
{
  UINT8  ByteSize;
  ByteSize = BitGetByteSize(BitOffset, BitSize);
  return (UINT64)(InputVal >> BitOffset) & (AndMask[ByteSize] >> ((ByteSize*8) - BitSize));
}

/**
  BIT wise Compare function 

  @param[in] Buffer 1 Ptr
  @param[in] Buffer 2 Ptr
  @param[in] Bit Offset within the given Byte (max Value of 7)
  @param[in] Bit Size (max value of 63)
  @param[in] CompareType (will be 0 if Source is Absolute Value that start at BIT00, else 1)

  @retval  BOOLEAN (TRUE if Value Matches)
**/
BOOLEAN
BitDataMatch64(
  VOID* Destination,
  VOID* Source,
  UINT8 BitOffset,
  UINT8 BitSize,
  UINT8 CompareType
  )
{
  UINT8  ByteSize;
  UINT64 BitMask;
  UINT64 DstVal=0;
  UINT64 SrcVal=0;
  ByteSize = BitGetByteSize(BitOffset, BitSize);
  BitMask = (UINT64)(AndMask[ByteSize] >> ((ByteSize*8) - BitSize));
  CopyMem(&DstVal,Destination, ByteSize);
  CopyMem(&SrcVal,Source, ByteSize);
  if(CompareType == 0) {
    SrcVal = (UINT64)(SrcVal & BitMask);
  } else {
    SrcVal = (UINT64)((SrcVal >> BitOffset) & BitMask);
  }
  DstVal = (UINT64)((DstVal >> BitOffset) & BitMask);
  if(SrcVal == DstVal) {
    return TRUE;
  } else {
    return FALSE;
  }
}

/**
  BIT wise Copy function 

  @param[in] Buffer 1 Ptr
  @param[in] Buffer 2 Ptr
  @param[in] Bit Offset within the given Byte (max Value of 7)
  @param[in] Bit Size (max value of 63)

  @retval  VOID
**/
VOID
BitDataCopy64(
  VOID* Destination,
  VOID* Source,
  UINT8 BitOffset,
  UINT8 BitSize
  )
{
  UINT8  ByteSize;
  UINT64 BitMask;
  UINT64 DstVal=0;
  UINT64 SrcVal=0;
  ByteSize = BitGetByteSize(BitOffset, BitSize);
  BitMask = ((UINT64)(AndMask[ByteSize] >> ((ByteSize*8) - BitSize)) << BitOffset);
  CopyMem(&DstVal,Destination, ByteSize);
  CopyMem(&SrcVal,Source, ByteSize);
  SrcVal = (UINT64)((SrcVal << BitOffset) & BitMask);
  DstVal = (UINT64)((DstVal & (~BitMask)) | SrcVal);
  CopyMem(Destination,(VOID*)&DstVal, ByteSize);
}

BOOLEAN IsKnobsDataBinValid( XML_CLI_TEMP_DATA *XmlCliTempData )
{
  UINT32        Data32;
  KNOB_BIN_HDR  *KnobBinHdr;

  CopyMem ( &Data32, (VOID*)(UINTN)(XmlCliTempData->LegacyMbAddr+OFF_BIOS_KNOBS_DATA_BIN_ADDR), 4);
  if(Data32) {
    KnobBinHdr = (KNOB_BIN_HDR*)(UINTN)Data32;
    if(KnobBinHdr->Hdr0.Signature == NVAR_SIGNATURE) {
      XmlCliTempData->BiosKnobsDataAddr = Data32;
      CopyMem ( &Data32, (VOID*)(UINTN)(XmlCliTempData->LegacyMbAddr+OFF_BIOS_KNOBS_DATA_BIN_SIZE), 4);
      XmlCliTempData->BiosKnobsDataSize = Data32;
      return TRUE;
    }
  }
  return FALSE;
}

/**
  Get Offset and size of the knob(setup variable)  from Bios Knobs Data bin.

  @param[in]     BiosKnobsDataAddr  Address of Bios knobs Data bin.
  @param[in]     BiosKnobsDataSize  Size of Bios knobs Data bin.
  @param[in]     VarName            Name of Nvar.
  @param[in]     VarGuid            Nvar Guid.
  @param[in,out] MyKnobList          List of knob for which Offset and size to be find.
                                      Size and offset will be part of the structure as output.
  @param[in]     MyKnobCount        Total number of knob for which Offset and size to be find.
  @param[in,out] NvarSize           Size of the setup variable

  @retval  UINT16
**/
UINT16
CliGetSetMyVariable (
  IN VOID      *XmlCliCom,
  IN UINT8     Operation,
  IN OUT VOID  *MyKnobList,
  IN UINT16     MyKnobCount
  )
{
  BOOLEAN         SkipThisNvar;
  BOOLEAN         ValidDataFound=FALSE;
  BOOLEAN         BitWise;
  UINT8           BitField;
  UINT8           KnobTypeSz;
  UINT8           CurKnobSize;
  CHAR8           DefName[64];
  CHAR16          UniCodeName[64];
  CHAR16          DefUniCodeName[64];
  UINT16          DataOffset;
  UINT16          Modified=0;
  UINT16          SetupModified=0;
  UINT16          Count=0;
  UINT16          CurCount=0;
  UINT32          Attributes=0;
  UINT32          DefAttributes=0;
  UINTN           VariableSize;
  UINTN           DefVariableSize;
  EFI_STATUS      Status;
  EFI_GUID        MyGuid;
  EFI_GUID        DefGuid;
  UINT8           *BufferPtr;
  UINT8           *KnobsBuffPtrStart;
  KNOB_LIST       *MyKnobListPtr;
  KNOB_BIN_HDR    *KnobBinHdr;
  VOID            *Setup=NULL;
  VOID            *DefSetup=NULL;
  //XML_CLI_COMMON  *XmlCliCommon;
  XML_CLI_TEMP_DATA *XmlCliTempData;

  MyKnobListPtr = (KNOB_LIST *)MyKnobList;
  for (Count=0; Count < MyKnobCount; Count++, MyKnobListPtr++) {
    MyKnobListPtr->KnobSize = 0;  // this also indicates that the knob was not processed.
    MyKnobListPtr->KnobOffset = 0;
  }
  //XmlCliCommon = (XML_CLI_COMMON*)XmlCliCom;
  XmlCliTempData = &mXmlCliTempData;
  if ((XmlCliTempData == 0) || (MyKnobCount == 0)) {
    return 0;
  }

  if ((XmlCliTempData->BiosKnobsDataAddr == 0) || (XmlCliTempData->BiosKnobsDataSize == 0)) {
    ValidDataFound = IsKnobsDataBinValid(XmlCliTempData);
  } else {
    KnobBinHdr = (KNOB_BIN_HDR*)(UINTN)XmlCliTempData->BiosKnobsDataAddr;
    if (KnobBinHdr->Hdr0.Signature == NVAR_SIGNATURE) {
      ValidDataFound = TRUE;
    } else {
      ValidDataFound = IsKnobsDataBinValid(XmlCliTempData);
    }
  }

  if (ValidDataFound != TRUE) {
    //DEBUG ((DEBUG_ERROR, "XML_CLI: gBiosKnobsDataBin FFS not found..\n"));
    return 0;
  }
  // DEBUG ((DEBUG_INFO, "BiosKnobsData Addr = 0x%X  Size = 0x%X MyKnobCount= %d\n", XmlCliTempData->BiosKnobsDataAddr, XmlCliTempData->BiosKnobsDataSize, MyKnobCount));

  if (Operation == GET_VAR) {
    (VOID) gBS->AllocatePool(EfiBootServicesData, 0x10000, (VOID**)&Setup);  // Allocate common 64K buffer for all Get Variables, will be faster.
  } else {
    (VOID) gBS->AllocatePool(EfiBootServicesData, 0x20000, (VOID**)&Setup);  // Allocate common 64K * 2 buffer for all Get Variables, will be faster.
    DefSetup = (VOID*) ((UINTN) Setup + 0x10000);
  }
  SetupModified = 0;
  for (KnobsBuffPtrStart = (UINT8*)(UINTN) XmlCliTempData->BiosKnobsDataAddr; (KnobsBuffPtrStart < (UINT8*)(UINTN)(XmlCliTempData->BiosKnobsDataAddr+XmlCliTempData->BiosKnobsDataSize)); ) {
    KnobBinHdr = (KNOB_BIN_HDR*) KnobsBuffPtrStart;
    if (CurCount >= MyKnobCount) {
      break;
    }
    if ((KnobBinHdr->Hdr0.Signature == NVAR_SIGNATURE) || (KnobBinHdr->Hdr0.Signature == NVRO_SIGNATURE)) {  // compare Signature with "$NVAR" or "$NVRO"
      MyGuid = KnobBinHdr->NvarGuid;
      VariableSize = 0;
      SkipThisNvar = FALSE;
      Modified = 0;
      for (BufferPtr=(KnobsBuffPtrStart+sizeof(KNOB_BIN_HDR)); ( (BufferPtr < (KnobsBuffPtrStart+KnobBinHdr->Hdr1.DupKnobBufOff)) && ( (UINT32)(UINTN) BufferPtr < (XmlCliTempData->BiosKnobsDataAddr+XmlCliTempData->BiosKnobsDataSize)));) {
        if (SkipThisNvar) {
          break;  // This Nvar has some issues, skip it
        }
        if (CurCount >= MyKnobCount) {
          break;
        }
        CopyMem(&DataOffset, BufferPtr, 2);
        BufferPtr = BufferPtr + 2;  // Aditionally ignore 1 byte of data (reserved for Knob Type[7:4] & KnobSize[3:0])
        CopyMem(&KnobTypeSz, BufferPtr, 1);
        BufferPtr = BufferPtr + 1;  // 1 byte of data (reserved for Knob Type[7:4] & KnobSize[3:0])
        BitWise = FALSE;
        CurKnobSize = 7;
        if ((KnobTypeSz & 0x80) == 0) {  // dont process EFI_IFR_STRING_OP
          if((KnobTypeSz & 0xF) >= 0xC) { // this indicates that the given Knob is Bitwise and is of Size mentioned in subsequent fields
            BitWise = TRUE;
            CopyMem (&BitField, BufferPtr, 1);
            BufferPtr = BufferPtr + 1;    // 1 byte of data Bitsize[7:3] BitOffset[2:0]
            CurKnobSize = BitGetByteSize((BitField & 0x7), ((BitField >> 3) & 0x3F));
          } else {
            CurKnobSize = (KnobTypeSz & 0xF);
          }
        }
        MyKnobListPtr = (KNOB_LIST *)MyKnobList;
        for (Count = 0; Count < MyKnobCount; Count++, MyKnobListPtr++) {
          if (MyKnobListPtr->KnobSize) {
            continue;  // This knob was processed already
          }
          if (AsciiStrCmp((CHAR8*)(VOID*)BufferPtr, MyKnobListPtr->KnobName) == 0) {
            if (VariableSize == 0) {
              MyKnobListPtr->VarId = (UINT8)KnobBinHdr->Hdr0.VarId;
              ZeroMem((VOID*)UniCodeName, sizeof(UniCodeName));  //Clear data
              AsciiStrToUnicodeStrS (KnobBinHdr->NvarName, UniCodeName, (sizeof (UniCodeName)/sizeof(CHAR16)));
              (VOID) gRT->GetVariable(UniCodeName, &MyGuid, &Attributes, &VariableSize, NULL);
              if (VariableSize != 0) {
                Status = gRT->GetVariable(UniCodeName, &MyGuid, &Attributes, &VariableSize, Setup);
                if (EFI_ERROR (Status)) {
                  //DEBUG ((DEBUG_INFO, "XML_CLI[GetSetMyVar]: Status=%r... Freeing up memory\n", Status));
                  SkipThisNvar = TRUE;
                  break;
                } else {
                  if (Operation == GET_DEF_CUR_VAR) {
                    AsciiStrCpyS((CHAR8*)DefName, sizeof(KnobBinHdr->NvarName), (CHAR8*)"Def");
                    AsciiStrCatS((CHAR8*)DefName, sizeof(KnobBinHdr->NvarName), (CHAR8*)KnobBinHdr->NvarName);
                    ZeroMem((VOID*)DefUniCodeName, sizeof(DefUniCodeName));  //Clear data
                    AsciiStrToUnicodeStrS ((CHAR8 *)DefName, DefUniCodeName, sizeof (DefUniCodeName));
                    DefGuid = MyGuid;
                    DefGuid.Data1 = 0xDEFA901D;
                    DefVariableSize = VariableSize;
                    Status = gRT->GetVariable(DefUniCodeName, &DefGuid, &DefAttributes, &DefVariableSize, DefSetup);
                    if (EFI_ERROR (Status)) {
                      CopyMem (DefSetup, Setup, VariableSize);
                    }
                  }
                }
              }
            }
            CurCount++;
            if (CurKnobSize == 7) {  // EFI_IFR_STRING_OP
              MyKnobListPtr->KnobSize = 0x7;  // Limit String Type knob's size to a non valid 7 bytes, this means we dont support String type knobs as of now.
              continue;
            } else {
              MyKnobListPtr->KnobSize = CurKnobSize;
            }
            MyKnobListPtr->KnobOffset = DataOffset;
            if ((VariableSize != 0) && (MyKnobListPtr->KnobSize <= sizeof(UINTN))) {
              if ((Operation == GET_VAR) || (Operation == GET_DEF_CUR_VAR)) {
                MyKnobListPtr->KnobValue = 0;
                CopyMem(&MyKnobListPtr->KnobValue, (UINT8*)Setup+DataOffset, MyKnobListPtr->KnobSize);
                if(BitWise) {
                  MyKnobListPtr->KnobValue = BitExtractValue64(MyKnobListPtr->KnobValue, (BitField & 0x7), ((BitField >> 3) & 0x3F));
                }
                if (Operation == GET_DEF_CUR_VAR) {
                  MyKnobListPtr->DefKnobValue = 0;
                  CopyMem(&MyKnobListPtr->DefKnobValue, (UINT8*)DefSetup+DataOffset, MyKnobListPtr->KnobSize);
                  if(BitWise) {
                    MyKnobListPtr->DefKnobValue = BitExtractValue64(MyKnobListPtr->DefKnobValue, (BitField & 0x7), ((BitField >> 3) & 0x3F));
                  }
                }
              } else if (Operation == GET_MOD_SET_VAR) {
                MyKnobListPtr->DefKnobValue = 0;
                CopyMem(&MyKnobListPtr->DefKnobValue, (UINT8*)DefSetup+DataOffset, MyKnobListPtr->KnobSize);
                if (MyKnobListPtr->KnobValue <= (0xFFFFFFFFFFFFFFFF >> (64-(8*MyKnobListPtr->KnobSize)))) {  // Allow only if input Value is within the Knob size range
                  if(BitWise) {
                    if(BitDataMatch64((VOID*)((UINT8*)Setup+DataOffset),(VOID*)&MyKnobListPtr->KnobValue, (BitField & 0x7), (BitField >> 3), 0) == FALSE) {
                      BitDataCopy64((VOID*)((UINT8*)Setup+DataOffset),(VOID*)&MyKnobListPtr->KnobValue, (BitField & 0x7), (BitField >> 3));
                      Modified++;
                      SetupModified++;
                    }
                  } else {
                    if (CompareMem((UINT8*)Setup+DataOffset, &MyKnobListPtr->KnobValue, MyKnobListPtr->KnobSize) != 0) {
                      CopyMem((UINT8*)Setup+DataOffset, &MyKnobListPtr->KnobValue, MyKnobListPtr->KnobSize);
                      Modified++;
                      SetupModified++;
                    }
                  }
                } else {
                  MyKnobListPtr->KnobValue = 0;
                  CopyMem(&MyKnobListPtr->KnobValue, (UINT8*)Setup+DataOffset, MyKnobListPtr->KnobSize);
                  if(BitWise) {
                    MyKnobListPtr->KnobValue = BitExtractValue64(MyKnobListPtr->KnobValue, (BitField & 0x7), ((BitField >> 3) & 0x3F));
                  }
                }
              }
            } else {
              MyKnobListPtr->KnobSize = 0;  // this means this specific Knob was not found or consider it as InValid
            }
            // DEBUG ((DEBUG_INFO, "%a[0x%04X][%d] = 0x%X\n", BufferPtr, DataOffset, MyKnobListPtr->KnobSize, MyKnobListPtr->KnobValue));
            if (CurCount >= MyKnobCount) {
              break;
            }
          }
        }
        // increment the knob name string
        while (*BufferPtr) {
          BufferPtr++;
        }
        BufferPtr++;  // Skip Null byte encounter
        // Skip the DEPEX
        while (*BufferPtr) {
          BufferPtr++;
        }
        BufferPtr++;  // Skip Null byte encounter
      }
      if (Modified) {
        Status = gRT->SetVariable(UniCodeName, &MyGuid, Attributes, VariableSize, Setup);
        if (EFI_ERROR (Status)) {
          //DEBUG ((DEBUG_ERROR, "XML_CLI[GetSetMyVar]: Set Variable Status = %r..for %s \n", Status, UniCodeName));
        }
      }
      KnobsBuffPtrStart = KnobsBuffPtrStart + KnobBinHdr->Hdr1.NvarPktSize;
    } else {
      KnobsBuffPtrStart = KnobsBuffPtrStart + sizeof(KNOB_BIN_HDR);
    }
  }
  // DEBUG ((DEBUG_INFO, "XML_CLI[GetSetMyVar]: Total Modified Knobs = %d \n", SetupModified));
  gBS->FreePool(Setup);
  return SetupModified;
}

EFI_STATUS
TianoDecompress (
 IN  VOID *SrcBuffer,
 IN  UINT32 SrcSize,
 IN  OUT VOID *DstBuffer,
 OUT UINT32 *DstSize
)
{
  EFI_STATUS  Status;
  UINT32      ScratchSize=0;
  VOID        *Scratch;

  Status = UefiDecompressGetInfo ( SrcBuffer, SrcSize, DstSize, &ScratchSize );
  if (EFI_ERROR (Status)) {
    return EFI_VOLUME_CORRUPTED;
  }

  if(DstBuffer == NULL) {
    return EFI_INVALID_PARAMETER;
  }

  Scratch = AllocatePool (ScratchSize);
  if (Scratch == NULL) {
    return EFI_OUT_OF_RESOURCES;
  }
  Status = UefiTianoDecompress (SrcBuffer, DstBuffer, Scratch, 2); //  2 for tiano Decompression
  FreePool (Scratch);
  return EFI_SUCCESS;
}

/***
  Print a welcoming message.
  Establishes the main structure of the application.
  @retval  0         The application exited normally.
  @retval  Other     An error occurred.
***/
EFI_STATUS
EFIAPI
TestXmlCliEntryPoint (
  IN EFI_HANDLE               ImageHandle,
  IN EFI_SYSTEM_TABLE         *SystemTable
  )
{
  EFI_STATUS         Status;
  XML_CLI_TEMP_DATA  *XmlCliTempData=&mXmlCliTempData;
  XML_CLI_API        *XmlCliApi=NULL;
  EFI_GUID           XmlCliCommonGuid = { 0xbf030b10, 0x2d9b, 0x4e71, { 0xa0, 0xc4, 0xbc, 0x99, 0x10, 0x57, 0x9d, 0x40 } };
  UINT8              *ImageBuffer, Count;
  UINT32             ImageLength;
  UINT32             DestinationSize=0;
  UINT64             PacketHdr;
  VOID               *Buffer=0;

  Print(L"Test XML CLI Load me first Driver\n");

  Status = gBS->LocateProtocol(&XmlCliCommonGuid, NULL, (VOID**)&XmlCliApi);
  if (EFI_ERROR(Status)) { // XmlCliCommon Protocol not published.
    return EFI_SUCCESS;
  }
  Status = ParseDramSharedMb(XmlCliTempData);
  if (EFI_ERROR(Status)) { // Dram Shared MB not published.
    return EFI_SUCCESS;
  }

  if(IsKnobsDataBinValid(XmlCliTempData)) {
    Print(L"Current BIOS supports desired Interface, no Action required, Returning..\n");
    return EFI_SUCCESS;  // interface already supports new XmlCli API, no AR here.
  }
  XmlCliApi->CliGetSetMyVariable = CliGetSetMyVariable;
  XmlCliApi->TianoDecompress = TianoDecompress;

  ImageBuffer = (UINT8*)(UINTN)((XmlCliTempData->GbtXmlAddress+4+XmlCliTempData->XmlSize+0xFFF) & 0xFFFFF000);
  for (Count = 0; Count < 2; Count++) {
    CopyMem ((VOID*)&PacketHdr, ImageBuffer, 8);
    ImageLength = ((PacketHdr >> 40) & 0xFFFFFF);
    if ( ((PacketHdr & 0xFFFFFFFFFF) == 0x424B4E5424) && (ImageLength != 0) ) { //  # cmp with $TNKB
      ImageBuffer = (UINT8*)(UINTN)(ImageBuffer+8);
      break;
    } else {
      ImageBuffer = (UINT8*)(UINTN)(((UINTN)ImageBuffer+8+ImageLength+0xFFF) & 0xFFFFF000);
    }
  }
  if(Count == 2) {
    return EFI_SUCCESS;
  }
  Print(L"Compressed BiosKnobs Databin Addr = 0x%X Size = 0x%X\n", ImageBuffer, ImageLength);
  Status = XmlCliApi->TianoDecompress( ImageBuffer, ImageLength, NULL, &DestinationSize );
  if(Status == EFI_INVALID_PARAMETER) {
    Status = gBS->AllocatePool (EfiReservedMemoryType, DestinationSize, (VOID**)&Buffer);
    if (EFI_ERROR (Status)) {
      return EFI_SUCCESS;
    }
    Status = XmlCliApi->TianoDecompress( ImageBuffer, ImageLength, Buffer, &DestinationSize );
    if (EFI_ERROR (Status)) {
      return EFI_SUCCESS;
    }
  }
  CopyMem((VOID*)(UINTN)(XmlCliTempData->LegacyMbAddr + OFF_BIOS_KNOBS_DATA_BIN_ADDR), &Buffer, 4);
  CopyMem((VOID*)(UINTN)(XmlCliTempData->LegacyMbAddr + OFF_BIOS_KNOBS_DATA_BIN_SIZE), (VOID*)&DestinationSize, 4);
  CopyMem ((VOID*)&PacketHdr, Buffer, 8);
  if ( (PacketHdr & 0xFFFFFFFFFF) == NVAR_SIGNATURE ) { //  # cmp with $NVAR
    XmlCliTempData->BiosKnobsDataAddr = (UINT32)(UINTN)Buffer;
    XmlCliTempData->BiosKnobsDataSize = DestinationSize;
    Print(L"DeCompressed BiosKnobs Databin Addr = 0x%X Size = 0x%X\n", Buffer, DestinationSize);
  }
  return EFI_SUCCESS;
}
