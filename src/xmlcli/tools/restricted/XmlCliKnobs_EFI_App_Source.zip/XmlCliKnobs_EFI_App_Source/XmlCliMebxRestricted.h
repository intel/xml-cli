/**
Copyright (c)  2022 Intel Corporation. All rights reserved
This software and associated documentation (if any) is furnished
under a license and may only be used or copied in accordance
with the terms of the license. Except as permitted by such
license, no part of this software or documentation may be
reproduced, stored in a retrieval system, or transmitted in any
form or by any means without the express written consent of
Intel Corporation.

@file:
  XmlCliMebxRestricted.h

@brief:
  Protocols and structure for XmlCli Mebx API functionality
**/

#include <Uefi.h>
#include <Library/UefiLib.h>
#include <Library/ShellCEntryLib.h>
#include <Library/ShellLib.h>
#include <Library/PrintLib.h>
#include <Library/UefiBootServicesTableLib.h>  // gBS
#include <Library/PrintLib.h>
#include <Library/BaseMemoryLib.h>

///
/// Mebx Config Protocol
/// The interface function is to set/get MEBX settings.
///

#define MEBX_VALIDATION_PROTOCOL_REVISION  1
#define MEBX_TEST_VERSION                  "0.0.1"
#define MEBX_ENABLE_AMT_SETTINGS           2
#define MEBX_DISABLE_AMT_SETTINGS          0
#define MEBX_KVM_ENABLE                    1
#define MEBX_SOL_ENABLE                    1
#define MEBX_IDER_ENABLE                   1
#define MEBX_FULL_UNPROVISION              1
#define INPUT_OK                           0
#define HDN_INVALID_CHARACTER              1
#define HDN_BAD_DOT                        2
#define HDN_LABEL_TOO_LONG                 3
#define HDN_NAME_TOO_LONG                  4
#define HDN_BAD_HYPHEN                     5
#define BAD_IP_ADDR                        6
#define BAD_IP_MASK                        7
#define BAD_IP_ADDR_MASK_COMBO             8
#define BAD_NEW_PWD                        9
#define HDN_DOMAIN_TOO_LONG                10


#define MAX_ASCII_STRING        192
#define MAX_STRING_LENGTH_FQDN  256
#define MAX_STRING_LENGTH_FQDN_SUFFIX 224

typedef struct {
  UINT16 Length;
  UINT8  Buffer[MAX_ASCII_STRING];
} IMB_ANSI_STRING;

typedef struct {
  UINT16 Length;
  UINT8  Buffer[MAX_STRING_LENGTH_FQDN];
} FQDN_ANSI_STRING;

typedef struct {
  UINT16 Length;
  UINT8  Buffer[MAX_STRING_LENGTH_FQDN_SUFFIX];
} FQDN_SUFFIX_ANSI_STRING;

typedef struct {
  UINT32          DhcpMode;
  UINT32          LocalAddr;
  UINT32          SubnetMask;
  UINT32          GatewayAddr;
  UINT32          PriDnsAddr;
  UINT32          SecDnsAddr;
  IMB_ANSI_STRING DomainName;
} IMB_TCPIP_PARAMS;

typedef struct {
  UINT32           SharedFqdn;
  UINT32           DdnsUpdateEnabled;          ///< Deprecated starting with ME 17.X
  UINT32           DdnsPeriodicUpdateInterval; ///< Deprecated starting with ME 17.X
  UINT32           DdnsTtl;                    ///< Deprecated starting with ME 17.X
  UINT32           HostNameLength;
  FQDN_ANSI_STRING Fqdn;
} FQDN_DATA;

/**
  This function will configure AMT settings based on the user input.

  @retval  Other        An error occurred.
  @retval  EFI_SUCCESS  Function executed successfully without error.
**/
EFI_STATUS
EFIAPI
ConfXmlCliMebxInit (
  IN CHAR16 **Argv
  );

///
/// Mebx Config Protocol
/// The interface function is to set/get MEBX settings.
///

#define MEBX_VALIDATION_PROTOCOL_REVISION  1

/**
  This function is used to log into MEBx. This function checks is password is modified then
  it validates the password and HECI lib with password change command will logs in with
  current password and updates to new password. If password is not modified HECI lib with
  validate command will be sent to validate the input password.

  @param[in] DefaultPassword      Default MEBx password data buffer
  @param[in] DefaultPasswordSize  The size in bytes of the default MEBx password data buffer
  @param[in] NewPassword          New MEBx password data buffer
  @param[in] NewPasswordSize      The size in bytes of the new MEBx password data buffer

  @retval  EFI_SUCCESS            Logged into MEBx successfully.
  @retval  EFI_INVALID_PARAMETER  Null parameter.
  @retval  EFI_BAD_BUFFER_SIZE    Password size exceeds 33 bytes (with termination) size.
**/
typedef
EFI_STATUS
(EFIAPI *MEBX_LOG_IN) (
  IN  CHAR8* DefaultPassword,
  IN  UINT8  DefaultPasswordSize,
  IN  CHAR8* NewPassword,
  IN  UINT8  NewPasswordSize
  );

/**
  This function is used to Activate Network in MEBx.

  @retval  EFI_SUCCESS  Logged into MEBx successfully.
  @retval  Others       Error during network activation has occured
**/
typedef
EFI_STATUS
(EFIAPI *MEBX_ACTIVATE_NETWORK) (
  VOID
  );

/**
  This function is used to configure IPV4 settings.

  @retval  EFI_SUCCESS  Configuration completed successfully.
  @retval  Others       Error during configuration has occured
**/
typedef
EFI_STATUS
(EFIAPI *MEBX_CONFIGURE_IPV4_PARAMETERS) (
  IN IMB_TCPIP_PARAMS *NewIpv4Cfg
  );

/**
  This function is used to configure Amt State.

  @param[in] AmtState  New AMT State:
                       @see AMT_STATE

  @retval  EFI_SUCCESS           Function succeeded
  @retval  EFI_UNSUPPORTED       Current ME mode doesn't support this function
  @retval  EFI_DEVICE_ERROR      HECI Device error, command aborts abnormally
  @retval  EFI_TIMEOUT           HECI does not return the buffer before timeout
  @retval  EFI_BUFFER_TOO_SMALL  Message Buffer is too small for the Acknowledge
**/
typedef
EFI_STATUS
(EFIAPI *MEBX_CONFIGURE_AMT_STATE) (
  IN UINT8 AmtState
  );

/**
  Performs Intel(R) AMT full and partial unprovisioning flows.
  Performs unprovisiong, re-initializes AMTHI, and if full unprovision, resets the
  MEBx password to AMT.

  @param[in] UnprovisionType  Specifies Unprovisioning Type:
                              0 - partial unprovision
                              1 - full unprovision

  @retval  EFI_SUCCESS  Unprovisioning successful
  @retval  EFI_TIMEOUT  Timeout has occured
  @retval  Others       Other error has occured
**/
typedef
EFI_STATUS
(EFIAPI *MEBX_CONDUCT_UNPROVISIONING) (
  IN UINT8 UnprovisionType
  );

/**
  This function is used to configure SOL and Storage Redirection state.

  @param[in] NewSolStatus           New SOL state
  @param[in] NewStorageRedirStatus  New Storage Redirection state

  @retval  EFI_SUCCESS           Command succeeded
  @retval  EFI_UNSUPPORTED       Current ME mode doesn't support this function
  @retval  EFI_DEVICE_ERROR      HECI Device error, command aborts abnormally
  @retval  EFI_TIMEOUT           HECI does not return the buffer before timeout
  @retval  EFI_BUFFER_TOO_SMALL  Message Buffer is too small for the Acknowledge
**/
typedef
EFI_STATUS
(EFIAPI *MEBX_CONFIGURE_SOL_STORAGE_REDIRECTION_STATE) (
  IN UINT16 NewSolStatus,
  IN UINT16 NewStorageRedirStatus
  );

/**
  This function is used to configure KVM Feature state.

  @param[in] KvmState  New KVM State

  @retval  EFI_SUCCESS           Command succeeded
  @retval  EFI_UNSUPPORTED       Current ME mode doesn't support this function
  @retval  EFI_DEVICE_ERROR      HECI Device error, command aborts abnormally
  @retval  EFI_TIMEOUT           HECI does not return the buffer before timeout
  @retval  EFI_BUFFER_TOO_SMALL  Message Buffer is too small for the Acknowledge
**/
typedef
EFI_STATUS
(EFIAPI *MEBX_CONFIGURE_KVM_STATE) (
  IN UINT32 KvmState
  );

/**
  This function is used to configure User Consent feature state for AMT Features:
  KVM / USB-R and Boot Parameters.

  @param[in] OptInState        Current OptInState
                               0          - None
                               1          - KVM
                               0xFFFFFFFF - All
  @param[in] RemoteOptInState  Enable / Disable Remote OptIn:
                               0 - Enabled
                               1 - Disabled

  @retval  EFI_SUCCESS           Command succeeded
  @retval  EFI_UNSUPPORTED       Current ME mode doesn't support this function
  @retval  EFI_DEVICE_ERROR      HECI Device error, command aborts abnormally
  @retval  EFI_TIMEOUT           HECI does not return the buffer before timeout
  @retval  EFI_BUFFER_TOO_SMALL  Message Buffer is too small for the Acknowledge
**/
typedef
EFI_STATUS
(EFIAPI *MEBX_CONFIGURE_OPT_IN_STATE) (
  IN UINT32 OptInState,
  IN UINT32 RemoteOptInState
  );

/**
  This function is used to configure AMT Idle Timeout.

  @param[in] AmtIdleTimeout  New AMT Idle Timeout

  @retval  EFI_SUCCESS           Command succeeded
  @retval  EFI_UNSUPPORTED       Current ME mode doesn't support this function
  @retval  EFI_DEVICE_ERROR      HECI Device error, command aborts abnormally
  @retval  EFI_TIMEOUT           HECI does not return the buffer before timeout
  @retval  EFI_BUFFER_TOO_SMALL  Message Buffer is too small for the Acknowledge
**/
typedef
EFI_STATUS
(EFIAPI *MEBX_CONFIGURE_IDLE_TIMEOUT) (
  IN UINT16 AmtIdleTimeout
  );

/**
  This function is used to configure Zero Touch Enabled State.

  @param[in] NewZtcStatus  New ZTC Enabled Status

  @retval  EFI_SUCCESS           Command succeeded
  @retval  EFI_UNSUPPORTED       Current ME mode doesn't support this function
  @retval  EFI_DEVICE_ERROR      HECI Device error, command aborts abnormally
  @retval  EFI_TIMEOUT           HECI does not return the buffer before timeout
  @retval  EFI_BUFFER_TOO_SMALL  Message Buffer is too small for the Acknowledge
**/
typedef
EFI_STATUS
(EFIAPI *MEBX_CONFIGURE_ZERO_TOUCH_STATE) (
  IN UINT32 NewZtcState
  );

/**
  This function is used to update MEBx password change policy.

  @param[in] PwdPolicy  New MEBx password change policy:
                        @see CFG_MEBX_PWD_CHANGE_POLICY

  @retval  EFI_SUCCESS           Command succeeded
  @retval  EFI_UNSUPPORTED       Current ME mode doesn't support this function
  @retval  EFI_DEVICE_ERROR      HECI Device error, command aborts abnormally
  @retval  EFI_TIMEOUT           HECI does not return the buffer before timeout
  @retval  EFI_BUFFER_TOO_SMALL  Message Buffer is too small for the Acknowledge
**/
typedef
EFI_STATUS
(EFIAPI *MEBX_CONFIGURE_MEBX_PWD_POLICY) (
  IN UINT32 PwdPolicy
  );

/**
  This function is used to update AMT Config Server data.

  @param[in] ServerPort  New Configuration Server Port Value
  @param[in] ServerAddr  New Configuration Server Address
  @param[in] Fqdn        New Fqdn Value

  @retval  EFI_SUCCESS            Command succeeded
  @retval  EFI_INVALID_PARAMETER  NULL parameter
  @retval  EFI_UNSUPPORTED        Current ME mode doesn't support this function
  @retval  EFI_DEVICE_ERROR       HECI Device error, command aborts abnormally
  @retval  EFI_TIMEOUT            HECI does not return the buffer before timeout
  @retval  EFI_BUFFER_TOO_SMALL   Message Buffer is too small for the Acknowledge
**/
typedef
EFI_STATUS
(EFIAPI *MEBX_UPDATE_AMT_CONFIG_SERVER_DATA) (
  IN UINT16           ServerPort,
  IN UINT8            *ServerAddr,
  IN FQDN_ANSI_STRING *Fqdn
  );

/**
  Update current FQDN Data.

  @param[in] FqdnData  New FQDN data

  @retval  EFI_SUCCESS            Command succeeded
  @retval  EFI_INVALID_PARAMETER  NULL parameter
  @retval  EFI_UNSUPPORTED        Current ME mode doesn't support this function
  @retval  EFI_DEVICE_ERROR       HECI Device error, command aborts abnormally
  @retval  EFI_TIMEOUT            HECI does not return the buffer before timeout
  @retval  EFI_BUFFER_TOO_SMALL   Message Buffer is too small for the Acknowledge
**/
typedef
EFI_STATUS
(EFIAPI *MEBX_UPDATE_FQDN) (
  IN FQDN_DATA *FqdnData
  );

/**
  Start the remote configuration process.

  @param[out] ProvisioningState  Platform provisioning state

  @retval  EFI_SUCCESS            Remote Configuration Activated
  @retval  EFI_INVALID_PARAMETER  NULL parameter
  @retval  EFI_UNSUPPORTED        Current ME mode doesn't support this function
  @retval  EFI_DEVICE_ERROR       HECI Device error, command aborts abnormally
  @retval  EFI_TIMEOUT            HECI does not return the buffer before timeout
  @retval  EFI_BUFFER_TOO_SMALL   Message Buffer is too small for the Acknowledge
  @retval  EFI_NOT_READY          Certificate not ready yet
**/
typedef
EFI_STATUS
(EFIAPI *MEBX_ACTIVATE_REMOTE_CONFIG) (
  OUT UINT32 *ProvisioningState
  );

/**
  Update current PKI FQDN DNS Suffix.

  @attention Function is not allowed in POST_PROVISION State

  @param[in] NewPkiDns               New Fqdn Pki Dns suffix

  @retval EFI_SUCCESS                Command succeeded
  @retval EFI_INVALID_PARAMETER      NULL parameter
  @retval EFI_UNSUPPORTED            Current ME mode doesn't support this function
  @retval EFI_DEVICE_ERROR           HECI Device error, command aborts abnormally
  @retval EFI_TIMEOUT                HECI does not return the buffer before timeout
  @retval EFI_BUFFER_TOO_SMALL       Message Buffer is too small for the Acknowledge
**/
typedef
EFI_STATUS
(EFIAPI *MEBX_UPDATE_PKI_FQDN_SUFFIX) (
  IN FQDN_SUFFIX_ANSI_STRING *NewPkiDns
  );

typedef struct {
  UINT8                                         Revision;
  MEBX_LOG_IN                                   MebxLogin;
  MEBX_ACTIVATE_NETWORK                         MebxActivateNetwork;
  MEBX_CONFIGURE_IPV4_PARAMETERS                MebxConfigureIpv4Parameters;
  MEBX_CONFIGURE_AMT_STATE                      MebxConfigureAmtState;
  MEBX_CONDUCT_UNPROVISIONING                   MebxConductUnprovisioning;
  MEBX_CONFIGURE_SOL_STORAGE_REDIRECTION_STATE  MebxConfigureSolStorageRedirectionState;
  MEBX_CONFIGURE_KVM_STATE                      MebxConfigureKvmState;
  MEBX_CONFIGURE_OPT_IN_STATE                   MebxConfigureOptInState;
  MEBX_CONFIGURE_IDLE_TIMEOUT                   MebxConfigureIdleTimeout;
  MEBX_CONFIGURE_ZERO_TOUCH_STATE               MebxConfigureZeroTouchState;
  MEBX_CONFIGURE_MEBX_PWD_POLICY                MebxConfigureMebxPwdPolicy;
  MEBX_UPDATE_AMT_CONFIG_SERVER_DATA            MebxUpdateAmtConfigServerData;
  MEBX_UPDATE_FQDN                              MebxUpdateFqdn;
  MEBX_ACTIVATE_REMOTE_CONFIG                   MebxActivateRemoteConfig;
  MEBX_UPDATE_PKI_FQDN_SUFFIX                   MebxUpdatePkiFqdnSuffix;
} MEBX_VALIDATION_PROTOCOL;
