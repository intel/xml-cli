## Steps to build XmlCli EFI app

1. Clone the EDK2 repo
   `git clone https://github.com/tianocore/edk2.git`

2. Clone the sub modules by performing following
    `cd edk2`
    `git submodule update --init`

    Refer [this](https://github.com/tianocore/edk2#readme) document for more details

3. Clone [EnableXmlCli](https://github.com/intel-sandbox/EnableXmlCli.git) repo
    `git clone https://github.com/intel-sandbox/EnableXmlCli.git`

4. Copy **XmlCliKnobs** folder inside `edk2/ShellPkg/Application/`

5. Add the following changes in the **ShellPkg/ShellPkg.dsc**

```ini
[LibraryClasses.common]
    TimerLib|MdePkg/Library/BaseTimerLibNullTemplate/BaseTimerLibNullTemplate.inf  
    OpensslLib|CryptoPkg/Library/OpensslLib/OpensslLib.inf  
    BaseCryptLib|CryptoPkg/Library/BaseCryptLib/BaseCryptLib.inf  
    IntrinsicLib|CryptoPkg/Library/IntrinsicLib/IntrinsicLib.inf  
    RngLib|MdePkg/Library/BaseRngLib/BaseRngLib.inf

[Components]
    ShellPkg/Application/XmlCliKnobs/XmlCliKnobs.inf
```
6. Add the following changes in the **edk2/Conf/target.txt**

```ini
TARGET_ARCH           = X64 
TOOL_CHAIN_TAG        = VS2019
```

## To Build the EFI app
1. Launch command prompt inside EDK2 folder and call `edksetup.bat`  
    - i.e `edk2> edksetup.bat`
2. Run `edk2> edksetup.bat rebuild`
3. Change the following in `edk2/Conf/target.txt`
    - `TARGET_ARCH           = X64`
4. build the ShellPkg `edk2> build -p <path to ShellPkg.dsc>` 
    - **example**: `D:\Prakash\Source_Code\edk2\edk2> build -p D:\Prakash\Source_Code\edk2\edk2\ShellPkg\ShellPkg.dsc`
5. Once the build is successful you will have the efi app in `edk2/Build/Shell/DEBUG_VS2015x86/X64/XmlCliKnobs.efi`
