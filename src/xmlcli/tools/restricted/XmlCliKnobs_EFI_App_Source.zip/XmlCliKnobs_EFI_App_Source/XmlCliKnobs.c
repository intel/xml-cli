/** @file
    A simple, basic, EDK II native, "hello" application to verify that
    we can build applications without LibC.

    Copyright (c) 2022, Intel Corporation. All rights reserved.<AS>
    This program and the accompanying materials
    are licensed and made available under the terms and conditions of the BSD License
    which accompanies this distribution. The full text of the license may be found at
    http://opensource.org/licenses/bsd-license.

    THE PROGRAM IS DISTRIBUTED UNDER THE BSD LICENSE ON AN "AS IS" BASIS,
    WITHOUT WARRANTIES OR REPRESENTATIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED.
**/
#include <XmlCliEfiShell.h>
//
// XmlCli:RestrictedBegin
//
#include <XmlCliMebxRestricted.h>
//
// XmlCli:RestrictedBegin
//
#define APP_VERSION           ("2.0.0")
#define TEMP_BUFFER_LENGTH    (1024*64)
#define DIGEST_SIZE_256       (0x20)  // 256-bits
#define GUID_SIZE             (0x10)  // 0x10 bytes
#define KEY_OFFSET            (GUID_SIZE)  // 0x10
#define KEY_SIZE              (0x20)  // 0x20 bytes random numbers to be generated
#define DIGEST_OFFSET         (GUID_SIZE + KEY_SIZE)  // 0x30
#define DIGEST_SIZE           (DIGEST_SIZE_256)

XML_CLI_DATA              mXmlCliData;


UINT32
GetDramSharedMbAddr (
  VOID
  )
{
  UINT32               DramMbAddress=0;
  SHARED_MEMORY_TABLE  *SharedMbTbl;

  IoWrite8(0x72, (UINT8)CMOS_DRAM_SHARED_MAILBOX_ADDR_REG);
  DramMbAddress = (((UINT32)IoRead8(0x73)) << 16);
  IoWrite8(0x72, (UINT8)CMOS_DRAM_SHARED_MAILBOX_ADDR_REG+1);
  DramMbAddress = ( DramMbAddress | (((UINT32)IoRead8(0x73)) << 24) );

  SharedMbTbl = (SHARED_MEMORY_TABLE*)(UINTN) DramMbAddress;
  if ((SharedMbTbl->Header.BiosSignature != SHARED_MB_BIOS_SIG) || (SharedMbTbl->Header.BiosSignature2 != SHARED_MB_BIOS_SIG)) {
    // Failed to read DRAM Shared Mailbox Address from F0 and F1
    IoWrite8(0x70, (UINT8)CMOS_DRAM_SHARED_MAILBOX_ADDR_REG_GNR);
    DramMbAddress = (((UINT32)IoRead8(0x71)) << 16);
    IoWrite8(0x70, (UINT8)CMOS_DRAM_SHARED_MAILBOX_ADDR_REG_GNR+1);
    DramMbAddress = (DramMbAddress | (((UINT32)IoRead8(0x71)) << 24));
  }
  return DramMbAddress;
}


BOOLEAN
XmlValid (
  IN UINT32  GbtXmlAddress
  )
{
  UINT32  XmlSize;
  CopyMem((VOID*)&XmlSize, (VOID*)(UINTN)GbtXmlAddress, 4);

  if (XmlSize != 0 ) {
    if ( ( CompareMem((VOID*)(UINTN)(GbtXmlAddress + 0x04), "<SYSTEM>", 8) == 0 ) &&
         ( CompareMem((VOID*)(UINTN)(GbtXmlAddress + XmlSize - 7 ), "</SYSTEM>", 9) == 0 ) ) {
      return TRUE;
    }
  }
  return FALSE;
}


EFI_STATUS
ParseDramSharedMb (
  IN OUT XML_CLI_DATA  *XmlCliData
  )
{
  SHARED_MEMORY_TABLE   *SharedMbTbl;

  XmlCliData->DramMbAddress = GetDramSharedMbAddr();
  SharedMbTbl = (SHARED_MEMORY_TABLE*)(UINTN)XmlCliData->DramMbAddress;
  XmlCliData->CliGen2_Enable = FALSE;
  //Print(L"\nInside Parse Dram shared MB DramMdAddress :0x%x\n",XmlCliData->DramMbAddress );
  if( (SharedMbTbl->Header.BiosSignature == SHARED_MB_BIOS_SIG) && (SharedMbTbl->Header.BiosSignature2 == SHARED_MB_BIOS_SIG) ) {
    //Print(L"Dram Shared MailBox is Valid,  SharedMbAddress: 0x%X\n", SharedMbTbl);
    if(SharedMbTbl->Entry[0].Signature == LEG_MAILBOX_SIG) {
      if( SharedMbTbl->Entry[0].Offset > 0xFFFF) {
        XmlCliData->LegacyMbAddr = (UINT32)SharedMbTbl->Entry[0].Offset;
      } else {
        XmlCliData->LegacyMbAddr = (UINT32)(UINTN)((UINT8*)SharedMbTbl + SharedMbTbl->Entry[0].Offset);
      }
      if( (SharedMbTbl->Header.CliSpecVersion.ReleaseVersion > 0) || (SharedMbTbl->Header.CliSpecVersion.MajorVersion > 6) ) {
        CopyMem((VOID*)&XmlCliData->GbtXmlAddress, (VOID*)(UINTN)(XmlCliData->LegacyMbAddr + OFF_GEN2_GBT_ADDRESS), 4);  // Get the GBT Xml address from Cli Gen2 Offset since Cli Gen2 is enabled
        XmlCliData->CliGen2_Enable = TRUE;
      } else {
        CopyMem((VOID*)&XmlCliData->GbtXmlAddress, (VOID*)(UINTN)(XmlCliData->LegacyMbAddr + OFF_GBT_ADDRESS), 4);
      }
      if(XmlValid(XmlCliData->GbtXmlAddress)) {
        CopyMem((VOID*)&XmlCliData->XmlSize, (VOID*)(UINTN)XmlCliData->GbtXmlAddress, 4);
        //Print(L"PlatformConfig.xml is Valid,  XMLAddress: 0x%X  XmlSize = 0x%X\n", XmlCliData->GbtXmlAddress, XmlCliData->XmlSize);
        CopyMem((VOID*)&XmlCliData->SetupKnobAddr, (VOID*)(UINTN)(XmlCliData->LegacyMbAddr + SETUP_KNOB_ADDRESS_OFF), 4);
        CopyMem((VOID*)&XmlCliData->SetupKnobSize, (VOID*)(UINTN)(XmlCliData->LegacyMbAddr + SETUP_KNOB_SIZE_OFF), 4);
      } else {
        Print(L"PlatformConfig.xml is not Valid,  XMLAddress: 0x%X  XmlSize = 0x%X\n", XmlCliData->GbtXmlAddress, XmlCliData->XmlSize);
        return EFI_NOT_FOUND;
      }
    }
    if(SharedMbTbl->Entry[1].Signature == CLI_REQ_SIG) {
      XmlCliData->CliReqBuff = SharedMbTbl->Entry[1].Offset;
    }
    if(SharedMbTbl->Entry[2].Signature == CLI_RES_SIG) {
      XmlCliData->CliResBuff = SharedMbTbl->Entry[2].Offset;
    }
    //Print(L" SetupKnobAddr: 0x%X  SetupKnobSize = 0x%X  \n CliReqBuff = 0x%X  CliResBuff =  = 0x%X\n", XmlCliData->SetupKnobAddr, XmlCliData->SetupKnobSize, XmlCliData->CliReqBuff, XmlCliData->CliResBuff);
  } else {
    Print(L"Dram Shared MailBox not Valid!, Address: 0x%X , aborting..\n", SharedMbTbl);
    return EFI_NOT_FOUND;
  }

  if( (XmlCliData->CliReqBuff == 0) || (XmlCliData->CliResBuff == 0) ) {
    Print(L"CLI buffers not Valid!\n");
    return EFI_NOT_FOUND;
  }
  return EFI_SUCCESS;
}


UINTN
GetToKnobEnd (
  IN OUT UINTN  XmlStartPointer
  )
{
  UINTN   Count;
  UINT64  XmlKnobEndTag;

  for (Count = 0; Count < 0x10000; Count++) {  // assuming each knob entry size wont exceed 64KB limit
    XmlKnobEndTag = *(UINT64*)(XmlStartPointer+Count);
    if((XmlKnobEndTag & BIOS_KNOB_END_TAG_1_MASK) == BIOS_KNOB_END_TAG_1) {
      return (XmlStartPointer + Count + BIOS_KNOB_END_TAG_1_SIZE - 1);
    }
    if((XmlKnobEndTag & BIOS_KNOB_END_TAG_2_MASK) == BIOS_KNOB_END_TAG_2) {
      return (XmlStartPointer + Count + BIOS_KNOB_END_TAG_2_SIZE - 1);
    }
  }
  return XmlStartPointer;
}


BOOLEAN
GetAtriVal (
  IN UINTN  XmlPointer,
  IN OUT CHAR8 *AtriValue
  )
{
  UINT16   Count;

  AtriValue[0] = 0;
  for (Count = 0; Count < 0x4000; Count++) {  // assuming each knob entry size wont exceed 16KB limit
    AtriValue[Count] = *(CHAR8*)(XmlPointer+Count);
    if( AtriValue[Count] == BIOS_KNOB_ATTR_END) {
      AtriValue[Count] = 0;
      break;
    }
  }
  if(AtriValue[0] == 0) {
    return FALSE;
  } else {
    return TRUE;
  }
}


BOOLEAN
ParseAttribute (
  IN UINTN      XmlPointer,
  IN UINT64     AtriTag1,
  IN UINT64     AtriTag2,
  IN UINT64     AtriTagMask,
  IN UINT8      AtriTagSize,
  IN OUT VOID   *AtriValue,
  IN BOOLEAN    IsAtriValInteger
  )
{
  UINTN   Count;
  UINT64  KnobAtriTag, AtriTag1Mask, AtriTag2Mask=0;
  UINT8   AtriTag1Size=AtriTagSize, AtriTag2Size=0;
  BOOLEAN AtriFound=FALSE;
  CHAR16  StringKnobData[64];

  if (AtriTag2 != 0) {
    AtriTag1Size = 8;
    AtriTag1Mask = 0xFFFFFFFFFFFFFFFF;
    AtriTag2Size = AtriTagSize;
    AtriTag2Mask = AtriTagMask;
  } else {
    AtriTag1Mask = AtriTagMask;
  }

  for (Count = 0; Count < 0x10000; Count++) {  // assuming each knob entry size wont exceed 64KB limit
    KnobAtriTag = *(UINT64*)(XmlPointer+Count);
    if( (KnobAtriTag & AtriTag1Mask) == AtriTag1) { // matches first tag
      if (AtriTag2 != 0) {
        KnobAtriTag = *(UINT64*)(XmlPointer+Count+AtriTag1Size);
        if( (KnobAtriTag & AtriTag2Mask) == AtriTag2) { // Matches second tag
          AtriFound = GetAtriVal(XmlPointer+Count+AtriTag1Size+AtriTag2Size, (CHAR8*)AtriValue);
          break;
        }
      } else {
        AtriFound = GetAtriVal(XmlPointer+Count+AtriTag1Size, (CHAR8*)AtriValue);
        break;
      }
    }
    if( ((KnobAtriTag & BIOS_KNOB_END_TAG_1_MASK) == BIOS_KNOB_END_TAG_1) || ((KnobAtriTag & BIOS_KNOB_END_TAG_2_MASK) == BIOS_KNOB_END_TAG_2) ) {
      break;
    }
  }

  if ( AtriFound && IsAtriValInteger) {
    AsciiStrToUnicodeStrS((CHAR8*)AtriValue, StringKnobData, (sizeof(StringKnobData)/sizeof(CHAR16)));
    if (EFI_ERROR(ShellConvertStringToUint64(StringKnobData, AtriValue, FALSE, TRUE))) {
      AtriFound = FALSE;
    }
  }
  return AtriFound;
}


VOID
MemSaveAsFile (
  IN OUT CHAR16 *Destination,
  IN OUT CHAR16 *AddressStr,
  IN OUT CHAR16 *SizeStr
  )
{
  UINTN                 ReadSize=0;
  UINTN                 Address=0;
  SHELL_FILE_HANDLE     DestHandle=NULL;
  EFI_STATUS            Status;
  VOID                  *Buffer;

  // open file with create enabled
  Status = ShellOpenFileByName(Destination, &DestHandle, EFI_FILE_MODE_READ|EFI_FILE_MODE_WRITE|EFI_FILE_MODE_CREATE, 0);
  if (EFI_ERROR(Status)) {
    Print(L"Cannot Open Destination File \n");
    return;
  }

  if (EFI_ERROR(ShellConvertStringToUint64(SizeStr, (UINT64 *)&ReadSize, FALSE, TRUE))) {
    Print(L"File Size is 0!\n");
    return;
  }

  if (EFI_ERROR(ShellConvertStringToUint64(AddressStr, (UINT64 *)&Address, FALSE, TRUE))) {
    Print(L"Address to copy from is 0!\n");
    return;
  }

  Buffer = AllocateZeroPool(ReadSize);
  if (Buffer == NULL) {
    Print(L"Error Allocating ZeroPool, PoolSize = 0x%X \n", ReadSize);
    return;
  }
  CopyMem(Buffer, (VOID*)(UINTN)Address, ReadSize);
  Status = FileHandleWrite(DestHandle, &ReadSize, Buffer);
  if (EFI_ERROR(Status)) {
    Print(L"Destination File Write error \n");
    return;
  }

  // close files
  if (DestHandle != NULL) {
    FileHandleClose(DestHandle);
    DestHandle = NULL;
  }
  if (Buffer != NULL) {
    FreePool(Buffer);
  }
  return;
}


VOID
GetBiosknobsBinData (
  IN OUT XML_CLI_DATA  *XmlCliData
  )
{
  EFI_STATUS               Status;
  UINT8                    Count;
  UINT8                    *ImageBuffer;
  UINT32                   ImageLength;
  UINT32                   DestinationSize=0;
  UINT64                   PacketHdr;
  VOID                     *Buffer=0;

  CopyMem((VOID*)&Buffer, (VOID*)(UINTN)(XmlCliData->LegacyMbAddr + OFF_BIOS_KNOBS_DATA_BIN_ADDR), 4);
  CopyMem((VOID*)&DestinationSize, (VOID*)(UINTN)(XmlCliData->LegacyMbAddr + OFF_BIOS_KNOBS_DATA_BIN_SIZE), 4);
  if (Buffer != 0) {
    CopyMem ((VOID*)&PacketHdr, Buffer, 8);
    if ( (PacketHdr & 0xFFFFFFFFFF) != NVAR_SIGNATURE ) { //  # cmp with $NVAR
      Buffer = 0;
    }
  }
  //Print(L"BiosKnobs Databin Addr = 0x%X Size = 0x%X\n", Buffer, DestinationSize);
  if ( (Buffer == 0) || (DestinationSize == 0) ) {
    ImageBuffer = (UINT8*)(UINTN)((XmlCliData->GbtXmlAddress+4+XmlCliData->XmlSize+0xFFF) & 0xFFFFF000);
    for (Count = 0; Count < 2; Count++) {
      CopyMem ((VOID*)&PacketHdr, ImageBuffer, 8);
      ImageLength = ((PacketHdr >> 40) & 0xFFFFFF);
      if ( ((PacketHdr & 0xFFFFFFFFFF) == 0x424B4E5424) && (ImageLength != 0) ) { //  # cmp with $TNKB
        ImageBuffer = (UINT8*)(UINTN)(ImageBuffer+8);
        break;
      } else {
        ImageBuffer = (UINT8*)(UINTN)(((UINTN)ImageBuffer+8+ImageLength+0xFFF) & 0xFFFFF000);
      }
    }
    if(Count == 2) {
      return;
    }
    //Print(L"Compressed BiosKnobs Databin Addr = 0x%X Size = 0x%X\n", ImageBuffer, ImageLength);
    if (XmlCliData->XmlCliApi == NULL) { // XmlCliCommon Protocol not published.
      Print(L"XmlCliCommon Protocol not published, returning! \n");
      return;
    }
    Status = ((XML_CLI_API*)XmlCliData->XmlCliApi)->TianoDecompress( ImageBuffer, ImageLength, NULL, &DestinationSize );
    if(Status == EFI_INVALID_PARAMETER) {
      Status = gBS->AllocatePool (EfiReservedMemoryType, DestinationSize, (VOID**)&Buffer);
      if (EFI_ERROR (Status)) {
        return;
      }
      Status = ((XML_CLI_API*)XmlCliData->XmlCliApi)->TianoDecompress( ImageBuffer, ImageLength, Buffer, &DestinationSize );
      if (EFI_ERROR (Status)) {
        return;
      }
    }
    CopyMem((VOID*)(UINTN)(XmlCliData->LegacyMbAddr + OFF_BIOS_KNOBS_DATA_BIN_ADDR), &Buffer, 4);
    CopyMem((VOID*)(UINTN)(XmlCliData->LegacyMbAddr + OFF_BIOS_KNOBS_DATA_BIN_SIZE), (VOID*)&DestinationSize, 4);
  }
  CopyMem ((VOID*)&PacketHdr, Buffer, 8);
  if ( (PacketHdr & 0xFFFFFFFFFF) == NVAR_SIGNATURE ) { //  # cmp with $NVAR
    XmlCliData->BiosKnobsDataAddr = (UINT32)(UINTN)Buffer;
    XmlCliData->BiosKnobsDataSize = DestinationSize;
    return;
  }
  return;
}


VOID
ConvHexArray2asciiVal (
  IN OUT CHAR8  *AsciiStr,
  IN UINT8      *InHexVal,
  IN UINTN      VarLength
  )
{
  UINTN Index=0;
  CHAR8  HexStr[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

  for (Index = 0; Index < VarLength; Index++) {
    AsciiStr[(Index*2)] = HexStr[((InHexVal[(VarLength-1-Index)] >> 4) & 0xF)];
    AsciiStr[(Index*2)+1] = HexStr[(InHexVal[(VarLength-1-Index)] & 0xF)];
  }
}

UINT64 AndMask[] = {0, 0xFF, 0xFFFF, 0xFFFFFF, 0xFFFFFFFF, 0xFFFFFFFFFF, 0xFFFFFFFFFFFF, 0xFFFFFFFFFFFFFF, 0xFFFFFFFFFFFFFFFF};


/**
  Extracts Byte Size from given BIT size
  @param[in] Bit Offset within the given Byte (max Value of 7)
  @param[in] Bit Size (max value of 63)

  @retval  UINT8 extracted byte Size
**/
UINT8
BitGetByteSize (
  IN UINT8  BitOffset,
  IN UINT8  BitSize
  )
{
  UINT8 ByteSize;
  ByteSize = BitOffset + BitSize;
  if(ByteSize % 8) {
    ByteSize = (ByteSize/8) + 1;
  } else {
    ByteSize = (ByteSize/8);
  }
  return ByteSize;
}


/**
  Extracts BIT Value from given Bit Offset for given Bit Size

  @param[in] UINT64 input Value
  @param[in] Bit Offset within the given Byte (max Value of 7)
  @param[in] Bit Size (max value of 63)

  @retval  UINT64 extracted Value
**/
UINT64
BitExtractValue64 (
  IN UINT64 InputVal,
  IN UINT8  BitOffset,
  IN UINT8  BitSize
  )
{
  UINT8  ByteSize;
  ByteSize = BitGetByteSize(BitOffset, BitSize);
  return (UINT64)(InputVal >> BitOffset) & (AndMask[ByteSize] >> ((ByteSize*8) - BitSize));
}


VOID
*XmlPrintf (
  IN OUT VOID *Address,
  IN OUT CHAR8 *sFormat,
  ...
  )
{
  UINTN   StrSize=0;
  VA_LIST Marker;
  if (sFormat != NULL) {
    VA_START (Marker, sFormat);
    StrSize = AsciiVSPrint (Address, TEMP_BUFFER_LENGTH, sFormat, Marker);
    VA_END (Marker);
  }
  Address = (VOID*)(UINTN)((UINT8*)Address + StrSize);
  return Address;
}


VOID
GenXmlLite (
  IN OUT XML_CLI_DATA  *XmlCliData,
  IN OUT CHAR16        *BiosKnobsFileName
  )
{
  EFI_STATUS         Status;
  SHELL_FILE_HANDLE  DestHandle=NULL;
  VOID               *Buffer=NULL;
  UINT8              Data8, KnobSize, Opcode, BitField, BitOffset, BitSize;
  BOOLEAN            BitWise;
  CHAR8              DefName[64];
  CHAR16             UniCodeName[64];
  CHAR16             DefUniCodeName[64];
  UINT16             KnobOffset;
  UINT32             Attributes=0;
  UINT32             DefAttributes=0;
  UINTN              VariableSize, XmlFileSize, DefVariableSize, DefKnobValue, KnobValue;
  EFI_GUID           MyGuid;
  EFI_GUID           DefGuid;
  UINT8              *BufferPtr, *KnobNamePtr, *DepexPtr, *TruePtr="TRUE";
  UINT8              *KnobsBuffPtrStart;
  KNOB_BIN_HDR       *KnobBinHdr;
  VOID               *Setup=NULL;
  VOID               *DefSetup=NULL;
  VOID               *CurrXmlPtr;
  CHAR8              *setupType;
  CHAR8              TmpStrCurVal[0x200];
  CHAR8              TmpStrDefVal[0x200];
  CHAR8              HexStr[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};
  UINT8              Val8, *TmpUint8Ptr;

  if ( (XmlCliData->BiosKnobsDataAddr == 0) || (XmlCliData->BiosKnobsDataSize == 0) ) {
    Print(L"Bios Knobs Bin Data not found, aborting..\n");
    return;
  }

  // open file with create enabled
  if (BiosKnobsFileName == NULL) {
    Status = ShellOpenFileByName(L"BiosKnobsLite.xml", &DestHandle, EFI_FILE_MODE_READ|EFI_FILE_MODE_WRITE|EFI_FILE_MODE_CREATE, 0);
    Print(L"Saving XML as BiosKnobsLite.xml\n");
  } else {
    Status = ShellOpenFileByName(BiosKnobsFileName, &DestHandle, EFI_FILE_MODE_READ|EFI_FILE_MODE_WRITE|EFI_FILE_MODE_CREATE, 0);
    Print(L"Saving XML as %S\n", BiosKnobsFileName);
  }
  if (EFI_ERROR(Status)) {
    Print(L"Cannot Open Destination File \n");
    return;
  }

  (VOID)gBS->AllocatePool(EfiBootServicesData, 0x20000, (VOID**)&Setup);  // Allocate common 64K * 2 buffer for all Get Variables, will be faster.
  DefSetup = (VOID*) ((UINTN) Setup + 0x10000);
  XmlFileSize = XmlCliData->BiosKnobsDataSize*4;
  Buffer = AllocateZeroPool(XmlFileSize);
  if (Buffer == NULL) {
    Print(L"Error Allocating ZeroPool, PoolSize = 0x%X \n", XmlFileSize);
    return;
  }
  CurrXmlPtr = Buffer;
  CurrXmlPtr = XmlPrintf(CurrXmlPtr, "<SYSTEM>\r\n\t<!--XmlLite Bios Knobs from BiosKnobsData Bin File -->\r\n");

  CurrXmlPtr = XmlPrintf(CurrXmlPtr, "\t<Nvars>\r\n");
  Data8 = 0;
  TmpUint8Ptr = (UINT8*)TmpStrCurVal;
  for (KnobsBuffPtrStart = (UINT8*)(UINTN) XmlCliData->BiosKnobsDataAddr; (KnobsBuffPtrStart < (UINT8*)(UINTN)(XmlCliData->BiosKnobsDataAddr+XmlCliData->BiosKnobsDataSize));) {
    KnobBinHdr = (KNOB_BIN_HDR*) KnobsBuffPtrStart;
    if ((KnobBinHdr->Hdr0.Signature == NVAR_SIGNATURE) || (KnobBinHdr->Hdr0.Signature == NVRO_SIGNATURE)) {  // compare Signature with "$NVAR" or "$NVRO"
      for (Opcode = 0; Opcode < Data8; Opcode++) {
        if(TmpUint8Ptr[Opcode] == (UINT8)KnobBinHdr->Hdr0.VarId) {
          break;
        }
      }
      if(Opcode == Data8) {
        CurrXmlPtr = XmlPrintf(CurrXmlPtr, "\t\t<Nvar varstoreIndex=\"%02d\" name=\"%a\" size=\"0x%04X\" KnobCount=\"%d\" guid=\"%g\"/>\r\n", KnobBinHdr->Hdr0.VarId, KnobBinHdr->NvarName, KnobBinHdr->NvarSize ,KnobBinHdr->Hdr0.KnobCount, KnobBinHdr->NvarGuid);
        TmpUint8Ptr[Data8] = (UINT8)KnobBinHdr->Hdr0.VarId;
        Data8++;
      }
      KnobsBuffPtrStart = KnobsBuffPtrStart + KnobBinHdr->Hdr1.NvarPktSize;
    } else {
      KnobsBuffPtrStart = KnobsBuffPtrStart + sizeof(KNOB_BIN_HDR);
    }
  }
  CurrXmlPtr = XmlPrintf(CurrXmlPtr, "\t</Nvars>\r\n");

  CurrXmlPtr = XmlPrintf(CurrXmlPtr, "\t<biosknobs>\r\n");
  for (KnobsBuffPtrStart = (UINT8*)(UINTN) XmlCliData->BiosKnobsDataAddr; (KnobsBuffPtrStart < (UINT8*)(UINTN)(XmlCliData->BiosKnobsDataAddr+XmlCliData->BiosKnobsDataSize));) {
    KnobBinHdr = (KNOB_BIN_HDR*) KnobsBuffPtrStart;
    BitWise = FALSE;  // Ensures that as default we set that knob is not a bitwise knob
    if ((KnobBinHdr->Hdr0.Signature == NVAR_SIGNATURE) || (KnobBinHdr->Hdr0.Signature == NVRO_SIGNATURE)) {  // compare Signature with "$NVAR" or "$NVRO"
      MyGuid = KnobBinHdr->NvarGuid;
      VariableSize = 0;
      ZeroMem((VOID*)UniCodeName, sizeof(UniCodeName));  //Clear data
      AsciiStrToUnicodeStrS (KnobBinHdr->NvarName, UniCodeName, (sizeof (UniCodeName)/sizeof(CHAR16)));
      (VOID) gRT->GetVariable(UniCodeName, &MyGuid, &Attributes, &VariableSize, NULL);
      if (VariableSize != 0) {
        Status = gRT->GetVariable(UniCodeName, &MyGuid, &Attributes, &VariableSize, Setup);
        if (EFI_ERROR (Status)) {
          KnobsBuffPtrStart = KnobsBuffPtrStart + KnobBinHdr->Hdr1.NvarPktSize;
          continue;
        } else {
          AsciiStrCpyS((CHAR8*)DefName, sizeof(KnobBinHdr->NvarName), (CHAR8*)"Def");
          AsciiStrCatS((CHAR8*)DefName, sizeof(KnobBinHdr->NvarName), (CHAR8*)KnobBinHdr->NvarName);
          ZeroMem((VOID*)DefUniCodeName, sizeof(DefUniCodeName));  //Clear data
          AsciiStrToUnicodeStrS ((CHAR8 *)DefName, DefUniCodeName, sizeof (DefUniCodeName));
          DefGuid = MyGuid;
          DefGuid.Data1 = 0xDEFA901D;
          DefVariableSize = VariableSize;
          Status = gRT->GetVariable(DefUniCodeName, &DefGuid, &DefAttributes, &DefVariableSize, DefSetup);
          if (EFI_ERROR (Status)) {
            CopyMem (DefSetup, Setup, VariableSize);
          }
        }
      } else {
        KnobsBuffPtrStart = KnobsBuffPtrStart + KnobBinHdr->Hdr1.NvarPktSize;
        continue;
      }
      for (BufferPtr=(KnobsBuffPtrStart+sizeof(KNOB_BIN_HDR)); ((BufferPtr < (KnobsBuffPtrStart+KnobBinHdr->Hdr1.DupKnobBufOff)) && ((UINT32)(UINTN) BufferPtr < (XmlCliData->BiosKnobsDataAddr+XmlCliData->BiosKnobsDataSize)));) {
        CopyMem(&KnobOffset, BufferPtr, 2);
        BufferPtr = BufferPtr + 2;  // Aditionally ignore 1 byte of data (reserved for Knob Type[7:4] & KnobSize[3:0])
        CopyMem(&Data8, BufferPtr, 1);
        BufferPtr = BufferPtr + 1;  // 1 byte of data (reserved for Knob Type[7:4] & KnobSize[3:0])
        if ((Data8 & 0x80)) {  // EFI_IFR_STRING_OP
          KnobSize = (Data8 & 0x7F) * 2;
          Opcode = EFI_IFR_STRING_OP;
          for (Data8 = 0; Data8 < KnobSize; Data8++) {
            Val8 = (UINT8)*((UINT8*)DefSetup+KnobOffset+(KnobSize-1-Data8));
            TmpStrDefVal[(Data8*2)] = HexStr[((Val8 >> 4) & 0xF)];
            TmpStrDefVal[(Data8*2)+1] = HexStr[(Val8 & 0xF)];
            Val8 = (UINT8)*((UINT8*)Setup+KnobOffset+(KnobSize-1-Data8));
            TmpStrCurVal[(Data8*2)] = HexStr[((Val8 >> 4) & 0xF)];
            TmpStrCurVal[(Data8*2)+1] = HexStr[(Val8 & 0xF)];
          }
          TmpStrDefVal[(KnobSize*2)] = '\0';
          TmpStrCurVal[(KnobSize*2)] = '\0';
        } else {
          KnobSize = (Data8 & 0xF);
          if(KnobSize >= 0xC) { // this indicates that the given Knob is Bitwise and is of Size mentioned in subsequent fields
            CopyMem (&BitField, BufferPtr, 1);
            BufferPtr = BufferPtr + 1;    // 1 byte of data Bitsize[7:3] BitOffset[2:0]
            BitWise   = TRUE;
            BitOffset = BitField & 0x7;
            BitSize   = (BitField >> 3) & 0x3F;
            KnobSize  = BitGetByteSize(BitOffset, BitSize);
          }
          if(KnobSize > 8) {
            KnobSize = 8;
          }
          Opcode = ((Data8 >> 4) & 0xF);
          if(Opcode < 0x4) {
            Opcode = Opcode + 0x4;  // This indicates that current Knob entry is part of Depex, Adjust the Type accordingly.
          }
          DefKnobValue = 0;
          KnobValue = 0;
          CopyMem(&KnobValue, (UINT8*)Setup+KnobOffset, KnobSize);
          CopyMem(&DefKnobValue, (UINT8*)DefSetup+KnobOffset, KnobSize);
          if(BitWise) {
            KnobValue = (UINTN) BitExtractValue64(KnobValue, BitOffset, BitSize);
            DefKnobValue = (UINTN) BitExtractValue64(DefKnobValue, BitOffset, BitSize);
          }
          ZeroMem ((VOID*)TmpStrDefVal, 20);
          ZeroMem ((VOID*)TmpStrCurVal, 20);
          ConvHexArray2asciiVal(TmpStrDefVal, (UINT8*)&DefKnobValue, KnobSize);
          ConvHexArray2asciiVal(TmpStrCurVal, (UINT8*)&KnobValue, KnobSize);
        }
        KnobNamePtr = BufferPtr;
        // increment the knob name string
        while (*BufferPtr) {
          BufferPtr++;
        }
        BufferPtr++;  // Skip Null byte encounter
        switch (Opcode) {
        case EFI_IFR_ONE_OF_OP:
          setupType = "oneof";
          break;
        case EFI_IFR_CHECKBOX_OP:
          setupType = "checkbox";
          break;
        case EFI_IFR_NUMERIC_OP:
          setupType = "numeric";
          break;
        case EFI_IFR_STRING_OP:
          setupType = "string";
          break;
        default:
          setupType = "??";
          break;
        }
        if(KnobBinHdr->Hdr0.Signature == NVRO_SIGNATURE) {
          setupType = "ReadOnly";
        }
        if (*BufferPtr) {  // check if Depex Ptr is NULL
          DepexPtr = BufferPtr;
        } else {
          DepexPtr = TruePtr;
        }
        if(BitWise) {
          CurrXmlPtr = XmlPrintf(CurrXmlPtr, "\t\t<knob setupType=\"%a\" name=\"%a\" varstoreIndex=\"%02d\" size=\"%02d\" offset=\"0x%05X\" depex=\"%a\" default=\"0x%a\" CurrentVal=\"0x%a\"/>\r\n", setupType, KnobNamePtr, KnobBinHdr->Hdr0.VarId, BitSize, (0xC0000 + (KnobOffset * 8) + BitOffset), DepexPtr, TmpStrDefVal, TmpStrCurVal);
        } else {
          CurrXmlPtr = XmlPrintf(CurrXmlPtr, "\t\t<knob setupType=\"%a\" name=\"%a\" varstoreIndex=\"%02d\" size=\"%02d\" offset=\"0x%04X\" depex=\"%a\" default=\"0x%a\" CurrentVal=\"0x%a\"/>\r\n", setupType, KnobNamePtr, KnobBinHdr->Hdr0.VarId, KnobSize, KnobOffset, DepexPtr, TmpStrDefVal, TmpStrCurVal);
        }
        // Skip the DEPEX
        while (*BufferPtr) {
          BufferPtr++;
        }
        BufferPtr++;  // Skip Null byte encounter
      }
      KnobsBuffPtrStart = KnobsBuffPtrStart + KnobBinHdr->Hdr1.NvarPktSize;
    } else {
      KnobsBuffPtrStart = KnobsBuffPtrStart + sizeof(KNOB_BIN_HDR);
    }
  }
  gBS->FreePool(Setup);
  CurrXmlPtr = XmlPrintf(CurrXmlPtr, "\t</biosknobs>\r\n</SYSTEM>\r\n");
  XmlFileSize = (UINTN)((UINTN)CurrXmlPtr - (UINTN)Buffer);
  Status = FileHandleWrite(DestHandle, &XmlFileSize, Buffer);
  if (EFI_ERROR(Status)) {
    Print(L"Destination File Write error \n");
    return;
  }

  // close files
  if (DestHandle != NULL) {
    FileHandleClose(DestHandle);
    DestHandle = NULL;
  }
  if (Buffer != NULL) {
    FreePool(Buffer);
  }
}


VOID
FetchHdrAndKnobs (
  IN OUT XML_CLI_DATA  *XmlCliData,
  IN OUT CHAR16        *BiosKnobsFileName
  )
{
  EFI_STATUS          Status;
  UINTN               XmlByteCount=0;
  SHELL_FILE_HANDLE   DestHandle=NULL;
  VOID                *Buffer=NULL;

  // open file with create enabled
  if (BiosKnobsFileName == NULL) {
    Status = ShellOpenFileByName(L"BiosKnobs.xml", &DestHandle, EFI_FILE_MODE_READ|EFI_FILE_MODE_WRITE|EFI_FILE_MODE_CREATE, 0);
    Print(L"Saved Bios Knobs section of XML as BiosKnobs.xml\n");
  } else {
    Status = ShellOpenFileByName(BiosKnobsFileName, &DestHandle, EFI_FILE_MODE_READ|EFI_FILE_MODE_WRITE|EFI_FILE_MODE_CREATE, 0);
    Print(L"Saved Bios Knobs section of XML as %S\n", BiosKnobsFileName);
  }
  if (EFI_ERROR(Status)) {
    Print(L"Cannot Open Destination File \n");
    return;
  }

  XmlByteCount = XmlCliData->XmlSize;
  Buffer = AllocateZeroPool(XmlByteCount);
  if (Buffer == NULL) {
    Print(L"Error Allocating ZeroPool, Alloc Size = 0x%X\n", XmlByteCount);
    return;
  }
  CopyMem((UINT8*)Buffer, (VOID*)(UINTN)(XmlCliData->GbtXmlAddress+4), XmlByteCount);
  Status = FileHandleWrite(DestHandle, &XmlByteCount, Buffer);
  if (EFI_ERROR(Status)) {
    Print(L"Destination File Write error \n");
    FreePool(Buffer);
    return;
  }

  if (DestHandle != NULL) {
    FileHandleClose(DestHandle);
    DestHandle = NULL;
  }
  FreePool(Buffer);
}


VOID
ParseXmlKnobs (
  IN OUT KNOB_INPUT_DATA  *KnobDataPtr,
  IN OUT XML_CLI_DATA     *XmlCliData
  )
{
  UINTN   XmlStartPointer, XmlEndPointer=(UINTN)(XmlCliData->SetupKnobAddr+XmlCliData->SetupKnobSize);
  UINT64  XmlKnobTag;
  UINT16  ReqKnobIndex=0;
  CHAR8   XmlKnobData[64];

  XmlCliData->ReqKnobEntriesProcessed=0;

  for (XmlStartPointer=(UINTN)XmlCliData->SetupKnobAddr; XmlStartPointer < XmlEndPointer; XmlStartPointer++) {
    XmlKnobTag = ((*(UINT64*)XmlStartPointer) & BIOS_KNOB_START_TAG_MASK) ;
    if(XmlKnobTag == BIOS_KNOB_START_TAG) { // Found Knob entry start, get Name
      if(ParseAttribute(XmlStartPointer, BIOS_KNOB_NAME_TAG, 0, BIOS_KNOB_NAME_TAG_MASK, BIOS_KNOB_NAME_TAG_SIZE, (VOID*)XmlKnobData, FALSE) == FALSE) continue;
      for (ReqKnobIndex=0; ReqKnobIndex < XmlCliData->ReqKnobEntries; ReqKnobIndex++) {
        if( (KnobDataPtr[ReqKnobIndex].ReqKnobName[0] == 0) || (KnobDataPtr[ReqKnobIndex].KnobFoundInXml) ) continue;   // Invalid or Already processed entry
        if(AsciiStrCmp(KnobDataPtr[ReqKnobIndex].ReqKnobName, XmlKnobData) == 0) { // Requested Knob found in XML, now get the knob details form XML
          if (ParseAttribute(XmlStartPointer, BIOS_KNOB_VARDID_TAG_1, BIOS_KNOB_VARDID_TAG_2, BIOS_KNOB_VARDID_TAG_2_MASK, BIOS_KNOB_VARDID_TAG_2_SIZE, (VOID*)XmlKnobData, TRUE)) {
            CopyMem(&KnobDataPtr[ReqKnobIndex].KnobVarId, (VOID*)XmlKnobData, 1);
          } else {
            KnobDataPtr[ReqKnobIndex].KnobVarId = 0xFF;
          }

          if(ParseAttribute(XmlStartPointer, BIOS_KNOB_SIZE_TAG, 0, BIOS_KNOB_SIZE_TAG_MASK, BIOS_KNOB_SIZE_TAG_SIZE, (VOID*)XmlKnobData, TRUE)) {
            CopyMem(&KnobDataPtr[ReqKnobIndex].KnobSize, (VOID*)XmlKnobData, 1);
          } else {
            KnobDataPtr[ReqKnobIndex].KnobSize = 1;
          }

          if(ParseAttribute(XmlStartPointer, BIOS_KNOB_OFFSET_TAG, 0, BIOS_KNOB_OFFSET_TAG_MASK, BIOS_KNOB_OFFSET_TAG_SIZE, (VOID*)XmlKnobData, TRUE)) {
            CopyMem(&KnobDataPtr[ReqKnobIndex].KnobOffset, (VOID*)XmlKnobData, 3);
            KnobDataPtr[ReqKnobIndex].KnobOffset = KnobDataPtr[ReqKnobIndex].KnobOffset & 0xFFFFF;
          } else {
            KnobDataPtr[ReqKnobIndex].KnobOffset = 0;
          }

          KnobDataPtr[ReqKnobIndex].KnobFoundInXml = TRUE;
          XmlCliData->ReqKnobEntriesProcessed++;
        }
      }
      XmlStartPointer = GetToKnobEnd(XmlStartPointer);
    }
    if(XmlCliData->ReqKnobEntriesProcessed == XmlCliData->ReqKnobValidEntries) break;  // done with requested entries, no need to parse the XML further
  }
}


UINT16
ParseInputKnobs (
  IN OUT KNOB_INPUT_DATA  *KnobDataPtr,
  IN OUT CHAR8            *KnobsString
  )
{
  UINT8   AsciiCount=0, StrValCount=0, FirstItera=0, InrFlag=0;
  CHAR16  ReqKnobStrValue[24];
  CHAR8   ReqKnobAsciiVal[24];
  UINT64  ReqKnobVal=0;
  UINT16  KnobEntryCount=0;

  ReqKnobStrValue[0] = 0;
  ReqKnobAsciiVal[0] = 0;
  do {
    //Print(L"0x%x  StrPointer = 0x%X \n", (*(UINT8*)KnobsString), KnobsString);
    if (FirstItera) { // skip for first iteration
      KnobsString++;
    } else {
      FirstItera++;
    }
    if (*KnobsString == ' ') {
      continue;
    }
    if ((*KnobsString == ';') || (*KnobsString == '[') ) { // treat comment accordingly
      while( (*KnobsString != '\n') && (*KnobsString != 0) ) { // loop until we reach end of line or end of string.
        KnobsString++;
      }
    }

    if (*KnobsString == '=') { // Lets read the given value
      KnobsString++;
      while(*KnobsString) {
        if (*KnobsString == ' ') {
          KnobsString++;
          continue;
        }
        if ((*KnobsString == ',') || (*KnobsString == '\n') || (*KnobsString == '\r')) {
          break;
        }
        ReqKnobAsciiVal[StrValCount] = *KnobsString;
        StrValCount++;
        KnobsString++;
      }
    }
    if ((*KnobsString == ',') || (*KnobsString == '\n')  || (*KnobsString == '\r') || (*KnobsString == 0)) { // end of given knob entry
      if (KnobDataPtr[KnobEntryCount].ReqKnobName[0] != 0) {
        ReqKnobAsciiVal[StrValCount] = 0;   // Add a NULL char
        ReqKnobVal = 0;
        if (ReqKnobAsciiVal[0] != 0) {
          AsciiStrToUnicodeStrS((CHAR8*)ReqKnobAsciiVal, ReqKnobStrValue, (sizeof(ReqKnobStrValue)/sizeof(CHAR16)));
          if (EFI_ERROR(ShellConvertStringToUint64(ReqKnobStrValue, &ReqKnobVal, FALSE, TRUE))) {
            ReqKnobVal = 0;
            KnobDataPtr[KnobEntryCount].InvalidInputKnobVal = TRUE;
          }
        } else {
          KnobDataPtr[KnobEntryCount].InvalidInputKnobVal = TRUE;
        }
        KnobDataPtr[KnobEntryCount].ReqKnobValue = ReqKnobVal;
        //Print(L" [%d]  ReqKnob Name = %a, ReqKnobValue = 0x%X \n", KnobEntryCount, KnobDataPtr[KnobEntryCount].ReqKnobName, KnobDataPtr[KnobEntryCount].ReqKnobValue);
        StrValCount = 0;
        KnobEntryCount++;
      }
      InrFlag = 0;
      while((*KnobsString == ',') || (*KnobsString == '\n')  || (*KnobsString == '\r')) { // get past the Knob and line ending characters
        KnobsString++;
        InrFlag = 1;
      }
      if (InrFlag)  KnobsString--;  // correct the incremental ++, since we will increment again on top of this loop
      AsciiCount = 0;
      if (*KnobsString == 0) {
        break;
      }
    } else {
      KnobDataPtr[KnobEntryCount].ReqKnobName[AsciiCount] = (CHAR8)*KnobsString;
      AsciiCount++;
    }
  } while(*KnobsString);

  return KnobEntryCount;
}


VOID
PrepareKnobsCliParamBuff (
  IN OUT KNOB_INPUT_DATA  *KnobDataPtr,
  IN OUT XML_CLI_DATA     *XmlCliData
  )
{
  UINT8   KnobLen;
  UINT16  count;
  UINTN   CurrCliReqBuffPtr=(UINTN)(XmlCliData->CliReqBuff+sizeof(CLI_BUFFER));

  for (count=0; count < XmlCliData->ReqKnobEntries; count++) {
    if( (KnobDataPtr[count].ReqKnobName[0] == 0) || (KnobDataPtr[count].KnobFoundInXml == FALSE) ) continue;   // skip invalid entry
    if( (XmlCliData->CommandId != READ_BIOS_KNOBS_OPCODE) && (KnobDataPtr[count].InvalidInputKnobVal) ) {
      Print(L"Warning: Invalid Input Value, Ignoring Requested Knob Entry= %a \n", KnobDataPtr[count].ReqKnobName);
      XmlCliData->ReqKnobEntriesProcessed--;  // Decrement Processed Knobs count
      continue;   // dont/prevent program invalid values
    }
    ((CLI_PROCESS_BIOS_KNOBS_RQST_PARAM*)CurrCliReqBuffPtr)->VarStoreIndex  = KnobDataPtr[count].KnobVarId;
    if (KnobDataPtr[count].KnobOffset >= 0xC0000) {  // is this a BitWise knob?
      ((CLI_PROCESS_BIOS_KNOBS_RQST_PARAM*)CurrCliReqBuffPtr)->KnobOffset = (1 << 15) | (UINT16)(KnobDataPtr[count].KnobOffset / 8);
      ((CLI_PROCESS_BIOS_KNOBS_RQST_PARAM*)CurrCliReqBuffPtr)->KnobSize   = (UINT8)(((KnobDataPtr[count].KnobSize & 0x3F) << 3) + ((KnobDataPtr[count].KnobOffset % 8) & 0x7));
      KnobLen  = BitGetByteSize(((KnobDataPtr[count].KnobOffset % 8) & 0x7), (KnobDataPtr[count].KnobSize & 0x3F));
    } else {
      ((CLI_PROCESS_BIOS_KNOBS_RQST_PARAM*)CurrCliReqBuffPtr)->KnobOffset = (UINT16)KnobDataPtr[count].KnobOffset;
      ((CLI_PROCESS_BIOS_KNOBS_RQST_PARAM*)CurrCliReqBuffPtr)->KnobSize   = KnobDataPtr[count].KnobSize;
      KnobLen  = KnobDataPtr[count].KnobSize;
    }
    CopyMem((VOID*)(CurrCliReqBuffPtr+sizeof(CLI_PROCESS_BIOS_KNOBS_RQST_PARAM)), &KnobDataPtr[count].ReqKnobValue, KnobLen);
    CurrCliReqBuffPtr = CurrCliReqBuffPtr + sizeof(CLI_PROCESS_BIOS_KNOBS_RQST_PARAM) + KnobLen;
  }
}

//
// XmlCli:RestrictedBegin
//

/**
  Generate XmlCli Hash at given Address pointer

  @param[in,out] AddressPtr  Pointer at which XmlCli reads input for digest

**/
UINT32
GenXmlCliHash (
  IN OUT VOID  *AddressPtr
  )
{
  UINT32   AdrCount;
  BOOLEAN  HashBufferFound=FALSE, HmacFound=FALSE;
  EFI_GUID XmlCliValidatorGuid = {0x5b8483ee, 0x0af6, 0x4ca0, {0x7c, 0x80, 0x31, 0x0d, 0xef, 0xd9, 0x4a, 0x32}};

  for (AdrCount=0; AdrCount < 0xFFFF; AdrCount+=0x40) {
    if (0x48d01987e3e49b8d == *(UINT64*)((UINTN)AddressPtr+AdrCount)) {
      if (0xd60BCA79A1ED019A == *(UINT64*)((UINTN)AddressPtr+AdrCount+8)) {
        HashBufferFound = TRUE;
        AddressPtr = (VOID*)((UINTN)AddressPtr + AdrCount);
        break;
      }
    } else if (0x4DA4F37CA8CBBBEA == *(UINT64*)((UINTN)AddressPtr+AdrCount)) {
      if (0x4912C56F4F68815E == *(UINT64*)((UINTN)AddressPtr+AdrCount+8)) {
        HmacFound = TRUE;
        AddressPtr = (VOID*)((UINTN)AddressPtr + AdrCount);
        break;
      }
    }
  }
  if (HmacFound) {
    UINT8    Digest[DIGEST_SIZE];
    VOID     *HmacContext;
    ZeroMem (Digest, DIGEST_SIZE);
    HmacContext = HmacSha256New();
    HmacSha256SetKey(HmacContext, (UINT8*)((UINTN)AddressPtr + KEY_OFFSET), KEY_SIZE);
    HmacSha256Update(HmacContext, (VOID*)&XmlCliValidatorGuid, GUID_SIZE);
    HmacSha256Final(HmacContext, Digest);
    CopyMem((VOID *)((UINTN) AddressPtr + DIGEST_OFFSET), &Digest, DIGEST_SIZE);
    HmacSha256Free(HmacContext);
    return (UINT32)(UINTN)AddressPtr;
  } else {
    return 0;
  }
}

//
// XmlCli:RestrictedEnd
//

EFI_STATUS
TriggerXmlCliApi (
  IN OUT KNOB_INPUT_DATA  *KnobDataPtr,
  IN OUT XML_CLI_DATA     *XmlCliData
  )
{
  EFI_STATUS  Status;
  UINTN       ResPointer, XmlPointer, DefVal=0, CurrVal=0;
  UINT8       KnobSize, VarId;
  UINT16      KnobOffset, count, Retries;
  UINT32      InterFaceAddr=0;
  CHAR8       XmlKnobData[64];
  UINTN       CurrCliResBuffPtr=(UINTN)(XmlCliData->CliResBuff+sizeof(CLI_BUFFER));
  CLI_BUFFER  *CliResBuffHdr=(CLI_BUFFER*)(UINTN)XmlCliData->CliResBuff;
  CHAR8       *ComandSideEffect[4] = {"NoSideEffect", "WarmResetRequired", "PowerGoodResetRequired", "Reserved"};

  InterFaceAddr = GenXmlCliHash((VOID*)(UINTN)(*(UINT32*)(UINTN)(XmlCliData->LegacyMbAddr + OFF_XML_CLI_TEMP_ADDR)));

  ((CLI_BUFFER*)(UINTN)XmlCliData->CliReqBuff)->CommandId        = XmlCliData->CommandId;
  ((CLI_BUFFER*)(UINTN)XmlCliData->CliReqBuff)->Flags.RawAccess  = 0;
  ((CLI_BUFFER*)(UINTN)XmlCliData->CliReqBuff)->Status           = 0;
  ((CLI_BUFFER*)(UINTN)XmlCliData->CliReqBuff)->ParametersSize   = XmlCliData->ReqKnobEntriesProcessed;
  if(XmlCliData->CliGen2_Enable) {
    ((CLI_BUFFER*)(UINTN)XmlCliData->CliReqBuff)->Signature      = CLI_GEN2_SGN_REQUEST_READY;
  } else {
    ((CLI_BUFFER*)(UINTN)XmlCliData->CliReqBuff)->Signature      = CLI_SGN_REQUEST_READY;
  }
  ZeroMem ((VOID*)(UINTN)XmlCliData->CliResBuff, sizeof(CLI_BUFFER));    // clear/initialize response buffer
  if(XmlCliData->DxeLoop){
    if (XmlCliData->XmlCliApi == NULL) { // XmlCliCommon Protocol not published.
      Print(L"XmlCliCommon Protocol not published, returning! \n");
      return EFI_NOT_FOUND;
    }
    Print(L"Entering Cli Loop via Dxe Entry Point.. \n");
    Status = ((XML_CLI_API*)XmlCliData->XmlCliApi)->DxeCliEntry(XmlCliData->XmlCliApi);
    Print(L"XmlCliApi->DxeCliEntry() Status: %r\n", Status);
  } else {
    Print(L"Entering Cli Loop via S/W SMI.. \n");
    IoWrite8(SW_SMI_PORT, SW_XML_CLI_ENTRY);    // Trigger S/W SMI
  }

  for(Retries=0; Retries < 10; Retries++) {
    if( (CliResBuffHdr->Signature == CLI_SGN_RESPONSE_READY) || (CliResBuffHdr->Signature == CLI_GEN2_SGN_RESPONSE_READY) ) {
      if( (CliResBuffHdr->Status == 0) && (CliResBuffHdr->CommandId == XmlCliData->CommandId) && (CliResBuffHdr->Flags.Fields.WrongParameter == 0) && (CliResBuffHdr->Flags.Fields.CannotExecute == 0) ) {
        Print (L"|---|------------|------------|---------------------------------------------\n");
        if (XmlCliData->CommandId != LOAD_DEFAULT_KNOBS_OPCODE) {
          Print (L"|KSz| DefaultVal | CurrentVal |     Knob Name                               \n");
        } else {
          Print (L"|KSz| PreviusVal | RestordVal |     Knob Name                               \n");
        }
      Print (L"|---|------------|------------|---------------------------------------------\n");
        for (ResPointer=CurrCliResBuffPtr; ResPointer < (CurrCliResBuffPtr+CliResBuffHdr->ParametersSize);) {
          XmlPointer = (UINTN)((CLI_PROCESS_BIOS_KNOBS_RSP_PARAM*)ResPointer)->KnobXmlEntryPtr;
          VarId = ((CLI_PROCESS_BIOS_KNOBS_RSP_PARAM*)ResPointer)->VarStoreIndex;
          KnobOffset = ((CLI_PROCESS_BIOS_KNOBS_RSP_PARAM*)ResPointer)->KnobOffset;
          if(KnobOffset & 0x8000) {  // if Bitwise knob
            KnobOffset = KnobOffset & 0x7FFF;
            KnobSize = ((CLI_PROCESS_BIOS_KNOBS_RSP_PARAM*)ResPointer)->KnobSize;
            KnobSize  = BitGetByteSize((KnobSize & 0x7), ((KnobSize >> 3) & 0x3F));
          } else {
            KnobSize = ((CLI_PROCESS_BIOS_KNOBS_RSP_PARAM*)ResPointer)->KnobSize;
          }
          DefVal = CurrVal = 0;
          CopyMem(&DefVal, (VOID*)(ResPointer+sizeof(CLI_PROCESS_BIOS_KNOBS_RSP_PARAM)), KnobSize);
          CopyMem(&CurrVal, (VOID*)(ResPointer+sizeof(CLI_PROCESS_BIOS_KNOBS_RSP_PARAM)+KnobSize), KnobSize);
          ResPointer = ResPointer + sizeof(CLI_PROCESS_BIOS_KNOBS_RSP_PARAM) + (KnobSize * 2);
          if(ParseAttribute(XmlPointer, BIOS_KNOB_NAME_TAG, 0, BIOS_KNOB_NAME_TAG_MASK, BIOS_KNOB_NAME_TAG_SIZE, (VOID*)XmlKnobData, FALSE) == FALSE) continue;
          if (KnobSize <=4) {
            Print (L"| %X | 0x%-8X | 0x%-8X | %a \n", KnobSize, DefVal, CurrVal, XmlKnobData);
          } else {
            Print (L"| %X | 0x%-16lX | 0x%-16lX | %a \n", KnobSize, DefVal, CurrVal, XmlKnobData);
          }
          if (XmlCliData->CommandId != LOAD_DEFAULT_KNOBS_OPCODE) {
            for (count=0; count < XmlCliData->ReqKnobEntries; count++) {
              if( (KnobDataPtr[count].ReqKnobName[0] == 0) || (KnobDataPtr[count].KnobFoundInXml == FALSE) )continue;   // skip invalid entry
              if(AsciiStrCmp(KnobDataPtr[count].ReqKnobName, XmlKnobData) == 0) {
                KnobDataPtr[count].DefKnobValue   = DefVal;
                KnobDataPtr[count].CurrKnobValue  = CurrVal;
                KnobDataPtr[count].KnobProcByCli  = TRUE;
                break;
              }
            }
          }
        }
        Print (L"|---|------------|------------|---------------------------------------------\n");
        Print (L"Side-Effect of XmlCli Knobs command is = \"%a\"\n", ComandSideEffect[CliResBuffHdr->Flags.Fields.CommandSideEffects]);
        return EFI_SUCCESS;
      }
    }
    IoRead8(0x80);    // dummy read to simulate the delay
  }
  Print(L"XML CLI Knobs Operation returned with error!, Aborting..\n");
  return EFI_NOT_FOUND;
}


VOID
FreeBuffers (
  IN OUT VOID  *KnobsString,
  IN OUT VOID  *KnobDataPtr
  )
{
  if (KnobsString != NULL) {
    FreePool(KnobsString);
  }
  if (KnobDataPtr != NULL) {
    FreePool(KnobDataPtr);
  }
}


CHAR8*
GetInKnobsString (
  IN OUT CHAR16 *KnobsInFormat,
  IN OUT CHAR16 *KnobArg
  )
{
  EFI_STATUS          Status;
  UINTN               ReadSize;
  SHELL_FILE_HANDLE   SourceHandle=NULL;
  CHAR8               *KnobsString=NULL;

  if(KnobsInFormat[0] == L'-') {
    if(KnobsInFormat[1] == L's') { // Knobs input in String format
      ReadSize = StrLen (KnobArg);
      KnobsString = AllocateZeroPool(ReadSize+4);  // 4 bytes with NULL value as a safety buffer
      if (KnobsString == NULL) {
        Print(L"Error Allocating ZeroPool, Alloc Size = 0x%X\n", ReadSize);
        return NULL;
      }
      UnicodeStrToAsciiStrS(KnobArg, KnobsString, (ReadSize+2));
    } else if (KnobsInFormat[1] == L'f') { // Knobs Input in cfg file format
      Status = ShellOpenFileByName(KnobArg, &SourceHandle, EFI_FILE_MODE_READ, 0);
      if (EFI_ERROR(Status)) {
        Print(L"Cannot Open Source File \n");
        return NULL;
      }
      Status = FileHandleGetSize(SourceHandle, (UINT64 *)&ReadSize);
      if (EFI_ERROR(Status)) {
        Print(L"Cannot Get Source File Size \n");
        return NULL;
      }
      KnobsString = AllocateZeroPool(ReadSize+4);  // 4 bytes with NULL value as a safety buffer
      if (KnobsString == NULL) {
        Print(L"Error Allocating ZeroPool, Alloc Size = 0x%X\n", ReadSize);
        return NULL;
      }
      Status = FileHandleRead(SourceHandle, &ReadSize, KnobsString);
      if (EFI_ERROR(Status)) {
        Print(L"Source Read File error \n");
        FreePool(KnobsString);
        return NULL;
      }
      if (SourceHandle != NULL) {
        FileHandleClose(SourceHandle);
        SourceHandle = NULL;
      }
    }
  }
  return KnobsString;
}


UINT8
ConfXmlCli (
  VOID
  )
{
  //
  // XmlCli:RestrictedBegin
  //
  UINT32 InterFaceAddr, Retries;
  SHARED_MEMORY_TABLE   *SharedMbTbl;

  InterFaceAddr = GetDramSharedMbAddr();
  SharedMbTbl = (SHARED_MEMORY_TABLE*)(UINTN)InterFaceAddr;
  //Print(L"\nInterFaceAddr :0x%x\n",InterFaceAddr );
  if( (SharedMbTbl->Header.BiosSignature == SHARED_MB_BIOS_SIG) && (SharedMbTbl->Header.BiosSignature2 == SHARED_MB_BIOS_SIG) ) {
    if(SharedMbTbl->Entry[0].Signature == LEG_MAILBOX_SIG) {
      Print(L"XmlCli support is already Enabled, Cli Spec version = %d.%d.%d\n", SharedMbTbl->Header.CliSpecVersion.ReleaseVersion, SharedMbTbl->Header.CliSpecVersion.MajorVersion, SharedMbTbl->Header.CliSpecVersion.MinorVersion);
      return 0;
    }
    if( (SharedMbTbl->Header.CliSpecVersion.ReleaseVersion > 0) || (SharedMbTbl->Header.CliSpecVersion.MajorVersion >= 8) ) {
      if(SharedMbTbl->Entry[0].Signature == XML_CLI_DISABLED_SIG) {
        InterFaceAddr = SharedMbTbl->Entry[0].Offset;
      }
    }
  }
  InterFaceAddr = GenXmlCliHash((VOID*)(UINTN)InterFaceAddr);
  if (InterFaceAddr) {
    Print(L"Enabling XmlCli Support..\n");
    IoWrite8(SW_SMI_PORT, SW_XML_CLI_ENTRY);    // Trigger S/W SMI
    for(Retries = 0; Retries < 10; Retries++) {
      if (0xB05ADC0D3EB0079A == *(UINT64*)((UINTN)InterFaceAddr+0x30)) {
        if (0xD095BE110E9AB1ED == *(UINT64*)((UINTN)InterFaceAddr+0x38)) {
          Print(L"Enabled XmlCli support Successfully, Please Reboot..\n");
          *(UINT64*)((UINTN)InterFaceAddr+0x30) = 0;
          *(UINT64*)((UINTN)InterFaceAddr+0x38) = 0;
          return 2;
        }
      }
    }
  }
  //
  // XmlCli:RestrictedEnd
  //
  Print(L"Interface Buffer Not Found, Aborting..\n");
  return 1;
}


VOID
PrintUsage (
  VOID
  )
{
  Print(L"Application Usage: <XmlCliKnobs.efi Operation [-s|-f] [KnobsStr|KnobsCfgFile]>\n");
  Print(L" (Save XML)       : <XmlCliKnobs.efi GX>\n");
  Print(L" (XML to MyFile)  : <XmlCliKnobs.efi GX fs0:\\MyBiosKnobs.xml>\n");
  Print(L" (Config XmlCli)  : <XmlCliKnobs.efi CX>\n\t\tHelps to check XmlCli is enabled or not. Also, can be used to Enable it.");
//
// XmlCli:RestrictedBegin
//
  Print(L"Following commands are XmlCli command for TPM settings\n");
  Print(L" (Enable TPM Settings) : <XmlCliKnobs.efi TPM 1>\n");
  Print(L" (Disable TPM Settings): <XmlCliKnobs.efi TPM 0>\n");
  Print(L"Following commands are XmlCli command for Mebx settings availabled by effort of XmlCli and MEBx team\n");
  Print(L" (Enable AMT Settings)        : <XmlCliKnobs.efi MEBX AP EnableAMT>\n");
  Print(L" (Set/Update Domain Name)     : <XmlCliKnobs.efi MEBX AP SetHostDomainName \"mtn.intel.com\">\n");
  Print(L" (Set Unprovisioning Settings): <XmlCliKnobs.efi MEBX AP SetUnprovisioning>\n");
  Print(L" (Enable PKI suffix update)   : <XmlCliKnobs.efi MEBX AP PKISuffixUpdate>\n");
  Print(L" (Disable AMT Settings)       : <XmlCliKnobs.efi MEBX AP DisableAMT>\n");
//
// XmlCli:RestrictedEnd
//
  Print(L"For following commands use DXE as additional last arg to have \n\tDxe loop as Cli Entry point, Default is S/W SMI based\n");
  Print(L" (Load Defaults)  : <XmlCliKnobs.efi LD \n");
  Print(L" (Read Only)      : <XmlCliKnobs.efi RO -s \"SetShellFirst, ForceSetup\">\n");
  Print(L" (Read+Verify)    : <XmlCliKnobs.efi RO -s \"SetShellFirst=1, ForceSetup=0\">\n");
  Print(L" (Read+Verify .cfg): <XmlCliKnobs.efi RO -f fs0:\\BiosKnobs.cfg>\n");
  Print(L" (Program+verify) : <XmlCliKnobs.efi AP -s \"SetShellFirst=1, ForceSetup=0\">\n");
  Print(L" (Prog+verfy .cfg): <XmlCliKnobs.efi AP -f fs0:\\BiosKnobs.cfg>\n");
  Print(L" (LD+AP+Verify)   : <XmlCliKnobs.efi RM -s \"SetShellFirst=1, ForceSetup=0\">\n");
  Print(L" (LD+AP+Verify .cfg): <XmlCliKnobs.efi RM -f fs0:\\BiosKnobs.cfg>\n");
  Print(L"Following commands are XmlCli Lite commands\n");
  Print(L" (Save XML Lite)      : <XmlCliKnobs.efi GXL>\n");
  Print(L" (XML Lite to MyFile) : <XmlCliKnobs.efi GXL fs0:\\MyBiosKnobs.xml>\n");
  Print(L" (Read Only) Lite     : <XmlCliKnobs.efi ROL -s \"SetShellFirst, ForceSetup\">\n");
  Print(L" (Read+Verify) Lite   : <XmlCliKnobs.efi ROL -s \"SetShellFirst=1, ForceSetup=0\">\n");
  Print(L" (Read+Verify .cfg)Lite: <XmlCliKnobs.efi ROL -f fs0:\\BiosKnobs.cfg>\n");
  Print(L" (Program+verify) Lite: <XmlCliKnobs.efi APL -s \"SetShellFirst=1, ForceSetup=0\">\n");
  Print(L" (Prog+Verify .cfg)Lite: <XmlCliKnobs.efi APL -f fs0:\\BiosKnobs.cfg>\n");
}


/***
  Print a welcoming message.
  Establishes the main structure of the application.
  @retval  0         The application exited normally.
  @retval  Other     An error occurred.
***/
INTN
EFIAPI
ShellAppMain (
  IN UINTN Argc,
  IN CHAR16 **Argv
  )
{
  EFI_STATUS       Status;
  CHAR16           *Operation, *EntryMode;
  CHAR8            *KnobsString=NULL;
  CHAR16           *BiosKnobsFileName=NULL;
  KNOB_INPUT_DATA  *KnobDataPtr=NULL;
  XML_CLI_DATA     *XmlCliData=&mXmlCliData;
  KNOB_LIST        *LiteKnobListPtr=NULL, *TempLiteKnobListPtr=NULL;
  UINT16           count, VerifyErrCnt=0, liteKnobCount=0, KnobsModified=0;
  VOID             *XmlCliApi=NULL;
  EFI_GUID         XmlCliCommonGuid = { 0xbf030b10, 0x2d9b, 0x4e71, { 0xa0, 0xc4, 0xbc, 0x99, 0x10, 0x57, 0x9d, 0x40 } };

  Print(L"Welcome to XML CLI Knobs EFI Utility, Version %a\n", APP_VERSION);

  if(Argc < 2) {
    Print(L"This EFI App expects min 1 args; See below for Usage and some eg.\n");
    PrintUsage();
    return(0);
  }
  Operation = (CHAR16*)Argv[1];
  if ((Operation[0] == L'-') && ((Operation[1] == L'v') || (Operation[1] == L'V'))) {
    Print(L"XmlCli Knobs EFI Utility, Version - %a\n", APP_VERSION);
    return(0);
  }
  if( (Operation[0] == L'T') && (Operation[1] == L'P') && (Operation[2] == L'M') ) { // Operation == Configure TPM ??
    EFI_GUID             XmlCliRtTpmProtocolGuid = {0xab51fc16, 0x1100, 0x4391, 0x86, 0xe7, 0x45, 0x58, 0xae, 0x52, 0xcf, 0x79};
    XML_CLI_TPM_PTT_API  *XmlCliRtTpmApiProtocol;
    Status = gBS->LocateProtocol(&XmlCliRtTpmProtocolGuid, NULL, (VOID**)&XmlCliRtTpmApiProtocol);
    if (EFI_ERROR(Status)) { // XmlCliCommon Protocol not published.
      Print(L"Aborting due to Error!\n");
      return(0);
    }
    if(((CHAR16*)Argv[2])[0] == L'0') {
//      Print(L"Setting PttPresent to Disable Starts!\n");
      XmlCliRtTpmApiProtocol->XmlCliRtTpmPtt(FALSE);
      Print(L"HECI Messaging for Setting PttPresent to Disable Done!\n");
    }
    if(((CHAR16*)Argv[2])[0] == L'1') {
//      Print(L"Setting PttPresent to Enable Starts!\n");
      XmlCliRtTpmApiProtocol->XmlCliRtTpmPtt(TRUE);
      Print(L"HECI Messaging for Setting PttPresent to Enable Done!\n");
    }
    return(0);
  }
//
// XmlCli:RestrictedBegin
//
  if ((Operation[0] == L'M') && (Operation[1] == L'E') && (Operation[2] == L'B') && (Operation[3] == L'X')) { // Operation == Configure MEBX ??
    Status = ConfXmlCliMebxInit(Argv);
    if (Status == EFI_INVALID_PARAMETER) {
      Print(L"For Mebx operation App expects min 3 args; See below for Usage and some eg.\n");
      PrintUsage();
    } else if (Status == EFI_SUCCESS) {
      Print(L"Mebx operations executed successfully \n");
    } else {
      Print(L"Mebx operations failed \n");
    }
    return(0);
  }
//
// XmlCli:RestrictedEnd
//
  if( (Operation[0] == L'C') && (Operation[1] == L'X') ) { // Operation == Configure XmlCli ??
    ConfXmlCli();
    return(0);
  }
  ZeroMem((VOID*)XmlCliData, sizeof(XML_CLI_DATA));  //Clear data
  Status = ParseDramSharedMb(XmlCliData);
  if (EFI_ERROR (Status)) {
    Print(L"Aborting due to Error!\n");
    return(0);
  }

  Status = gBS->LocateProtocol(&XmlCliCommonGuid, NULL, (VOID**)&XmlCliApi);
  if (EFI_ERROR(Status)) { // XmlCliCommon Protocol not published.
    XmlCliApi = NULL;
  }
  XmlCliData->XmlCliApi = XmlCliApi;

  XmlCliData->DxeLoop = FALSE;  // This means default to S/W SMI method.
  if(Operation[2] == L'L') {  // XmlLite operation?
    XmlCliData->XmlLiteOp = TRUE;
    GetBiosknobsBinData(XmlCliData);
  }
  if( (Operation[0] == L'R') && (Operation[1] == L'O') ) { // Operation == Read Bios Knobs ??
    XmlCliData->CommandId = READ_BIOS_KNOBS_OPCODE;
  } else if( (Operation[0] == L'A') && (Operation[1] == L'P') ) { // Operation == Append ??
    XmlCliData->CommandId = APPEND_BIOS_KNOBS_OPCODE;
  } else if( (Operation[0] == L'R') && (Operation[1] == L'M') ) { // Operation == Restore Modify ??
    XmlCliData->CommandId = RESTORE_MODIFY_KNOBS_OPCODE;
  } else if( (Operation[0] == L'L') && (Operation[1] == L'D') ) { // Operation == Load Defaults ??
    XmlCliData->CommandId = LOAD_DEFAULT_KNOBS_OPCODE;
    if(Argc >= 3) {
      EntryMode = (CHAR16*)Argv[2];
      if( (EntryMode[0] == L'D') && (EntryMode[1] == L'X') && (EntryMode[2] == L'E') ) {  // compare with 'DXE'
        XmlCliData->DxeLoop = TRUE;
      }
    }
    Status = TriggerXmlCliApi(KnobDataPtr, XmlCliData);
    return(0);
  } else if( (Operation[0] == L'G') && (Operation[1] == L'X') ) { // Operation == Save Bios knobs XML ??
    if(Argc > 2) {
      BiosKnobsFileName = (CHAR16*)Argv[2];
    }
    if(XmlCliData->XmlLiteOp == TRUE) {
      GenXmlLite(XmlCliData, BiosKnobsFileName);    // Generate XML Knobs info from BiosKnobsBin Data
    } else {
      FetchHdrAndKnobs(XmlCliData, BiosKnobsFileName);    // fetch and save XML Knobs section to BiosKnobs.xml file for future reference
    }
    return(0);
  } else if( (Operation[0] == L'M') && (Operation[1] == L'S') ) { // Operation == Save given Memory details in given File ??
    if(Argc == 5) {
      MemSaveAsFile( Argv[2], Argv[3], Argv[4] );
    }
    return(0);
  } else {
    Print(L"Unsupported Operation!, aborting..\n");
    return(0);
  }

  if(Argc < 4) {
    Print(L"For this operation App expects min 3 args; See below for Usage and some eg.\n");
    PrintUsage();
    return(0);
  }
  if(Argc > 4) {
    EntryMode = (CHAR16*)Argv[4];
    if( (EntryMode[0] == L'D') && (EntryMode[1] == L'X') && (EntryMode[2] == L'E') ) {  // compare with 'DXE'
      XmlCliData->DxeLoop = TRUE;
    }
  }
  KnobsString = GetInKnobsString(Argv[2], Argv[3]);
  if (KnobsString == NULL) {
    return(0);
  }
//  Print(L"Input Args: <%S> <%S> <%S>\n", (CHAR16*)Argv[1], (CHAR16*)Argv[2], (CHAR16*)Argv[3]);
//  Print(L"Input Knob string : %a\n", KnobsString);

  KnobDataPtr = AllocateZeroPool(sizeof(KNOB_INPUT_DATA)*0x2000); // 8K Knobs handling capability
  if (KnobDataPtr == NULL) {
    Print(L"Error Allocating ZeroPool, Alloc Size = 0x%X\n", (sizeof(KNOB_INPUT_DATA)*0x2000));
    FreeBuffers(KnobsString, KnobDataPtr);
    return(0);
  }

//    Print(L"Knob String:  |%a|\n", KnobsString);
  XmlCliData->ReqKnobEntries = ParseInputKnobs(KnobDataPtr, KnobsString);
  XmlCliData->ReqKnobValidEntries = 0;
//  Print(L"No of Entries found: %d\n", XmlCliData->ReqKnobEntries);
  for (count=0; count < XmlCliData->ReqKnobEntries; count++) {
    if(KnobDataPtr[count].ReqKnobName[0] == 0) continue;
    XmlCliData->ReqKnobValidEntries++;
//    Print(L"Knob Entry:  KnobName = %a   ReqVal (H) = %d (0x%X)\n", KnobDataPtr[count].ReqKnobName, KnobDataPtr[count].ReqKnobValue, KnobDataPtr[count].ReqKnobValue);
  }

  if(XmlCliData->XmlLiteOp) {  // XmlLite operation?
    LiteKnobListPtr = AllocateZeroPool(sizeof(KNOB_LIST)*XmlCliData->ReqKnobValidEntries);
    TempLiteKnobListPtr = LiteKnobListPtr;
    liteKnobCount = 0;
    for (count=0; count < XmlCliData->ReqKnobEntries; count++) {
      if(KnobDataPtr[count].ReqKnobName[0] == 0) continue;
      TempLiteKnobListPtr->KnobName  = KnobDataPtr[count].ReqKnobName;
      TempLiteKnobListPtr->KnobValue = (UINTN) KnobDataPtr[count].ReqKnobValue;
      liteKnobCount++;
      TempLiteKnobListPtr++;
    }
    if(XmlCliData->CommandId == READ_BIOS_KNOBS_OPCODE) {
      KnobsModified = ((XML_CLI_API*)XmlCliData->XmlCliApi)->CliGetSetMyVariable(XmlCliData->XmlCliApi, GET_DEF_CUR_VAR, (VOID *) LiteKnobListPtr, liteKnobCount);
    }
    if(XmlCliData->CommandId == APPEND_BIOS_KNOBS_OPCODE) {
      KnobsModified = ((XML_CLI_API*)XmlCliData->XmlCliApi)->CliGetSetMyVariable(XmlCliData->XmlCliApi, GET_MOD_SET_VAR, (VOID *) LiteKnobListPtr, liteKnobCount);
    }
    XmlCliData->ReqKnobValidEntries = 0;
    TempLiteKnobListPtr = LiteKnobListPtr;
    Print (L"|---|------------|------------|---------------------------------------------\n");
    if (XmlCliData->CommandId != LOAD_DEFAULT_KNOBS_OPCODE) {
      Print (L"|KSz| DefaultVal | CurrentVal |     Knob Name                               \n");
    } else {
      Print (L"|KSz| PreviusVal | RestordVal |     Knob Name                               \n");
    }
    Print (L"|---|------------|------------|---------------------------------------------\n");
    for (count=0; count < liteKnobCount; count++) {
      if( (TempLiteKnobListPtr->KnobSize != 0) && (TempLiteKnobListPtr->KnobSize != 7) ) {
        if (TempLiteKnobListPtr->KnobSize <=4) {
          Print (L"| %X | 0x%-8X | 0x%-8X | %a \n", TempLiteKnobListPtr->KnobSize, TempLiteKnobListPtr->DefKnobValue, TempLiteKnobListPtr->KnobValue, TempLiteKnobListPtr->KnobName);
        } else {
          Print (L"| %X | 0x%-16lX | 0x%-16lX | %a \n", TempLiteKnobListPtr->KnobSize, TempLiteKnobListPtr->DefKnobValue, TempLiteKnobListPtr->KnobValue, TempLiteKnobListPtr->KnobName);
        }
      }
      TempLiteKnobListPtr++;
    }
    Print (L"|---|------------|------------|---------------------------------------------\n");
    if(KnobsModified) {
      Print (L"Side-Effect of XmlCli Knobs command is = \"%a\"\n", "PowerGoodResetRequired");
    } else {
      Print (L"Side-Effect of XmlCli Knobs command is = \"%a\"\n", "NoSideEffect");
    }
    return(0);
  }

  if( (XmlCliData->SetupKnobAddr != 0) && (XmlCliData->SetupKnobSize != 0) ) {
    ParseXmlKnobs(KnobDataPtr, XmlCliData);
    if(XmlCliData->ReqKnobEntriesProcessed) {
      PrepareKnobsCliParamBuff(KnobDataPtr, XmlCliData);
      if (XmlCliData->ReqKnobEntriesProcessed == 0) {
        Print(L"No Input entries processed!\n");
        FreeBuffers(KnobsString, KnobDataPtr);
        return(0);
      }
      Status = TriggerXmlCliApi(KnobDataPtr, XmlCliData);
      if (!EFI_ERROR(Status)) {   // if XML CLI API return with success
        for (count=0; count < XmlCliData->ReqKnobEntries; count++) {
          if( (KnobDataPtr[count].ReqKnobName[0] == 0) || (KnobDataPtr[count].KnobFoundInXml == FALSE) || (KnobDataPtr[count].InvalidInputKnobVal) ) continue;   // skip invalid entry
          if(KnobDataPtr[count].KnobProcByCli) {
            if (KnobDataPtr[count].CurrKnobValue != KnobDataPtr[count].ReqKnobValue) {
              VerifyErrCnt++;
              Print (L"Verify Fail: Knob = %a  ReqVal = 0x%lX CurrVal = 0x%lX \n", KnobDataPtr[count].ReqKnobName, KnobDataPtr[count].ReqKnobValue, KnobDataPtr[count].CurrKnobValue);
            }
          }
        }
        if(VerifyErrCnt) {
          Print(L"Verify Failed!\n");
        } else {
          Print(L"Verify Passed!\n");
        }
      }
    } else {
      Print(L"No Input entries processed!\n");
    }
  } else {
    Print(L"Setup Knobs Data Not Valid, Try Xml lite Commands!\n");
  }
  FreeBuffers(KnobsString, KnobDataPtr);
  return(0);
}
